Tekst ujednolicony sporządzony na podstawie: 

uchwały nr 492/2019 Komisji Nadzoru Finansowego z dnia 3 grudnia 2019 r. w sprawie wydania Rekomendacji S dotyczącej dobrych praktyk w zakresie zarządzania ekspozycjami kredytowymi zabezpieczonymi hipotecznie uchwały nr 173/2020 Komisji Nadzoru Finansowego z dnia 14 lipca 2020 r. zmieniającej uchwałę w sprawie wydania Rekomendacji S dotyczącej dobrych praktyk w zakresie zarządzania ekspozycjami kredytowymi zabezpieczonymi hipotecznie oraz uchwały nr 242/2023 Komisji Nadzoru Finansowego z dnia 19 czerwca 2023 r. zmieniającej uchwałę w sprawie wydania Rekomendacji S dotyczącej dobrych praktyk w zakresie zarządzania ekspozycjami kredytowymi zabezpieczonymi hipotecznie 

# Komisja Nadzoru Finansowego 

## **Rekomendacja S** 

dotycząca dobrych praktyk w zakresie zarządzania ekspozycjami kredytowymi zabezpieczonymi hipotecznie 

Warszawa, grudzień 2019 r. 

## **Wstęp** 

Rekomendacja wydana jest na podstawie art. 137 ust. 1 pkt 5 ustawy z dnia 29 sierpnia 1997 r. – Prawo bankowe (Dz. U. z 2022 r. poz. 2324, z późn. zm.) i stanowi zbiór zasad dotyczących dobrych praktyk w zakresie ekspozycji kredytowych zabezpieczonych hipotecznie. 

Celem wydania znowelizowanej Rekomendacji S jest rozszerzenie jej dotychczasowego brzmienia, o zasady dotyczące zarządzania ekspozycjami kredytowymi zabezpieczonymi hipotecznie oprocentowanymi stałą stopą procentową lub okresowo stałą stopą procentową, tak aby uwzględnić ryzyko związane z tymi kredytami oraz wskazanie, że banki powinny posiadać w ofercie kredytów zabezpieczonych hipotecznie na nieruchomościach mieszkalnych dla klientów detalicznych, również takie rodzaje kredytów. Znowelizowana Rekomendacja S wskazuje, że bank powinien umożliwić klientowi detalicznemu zmianę formuły oprocentowania kredytu ze zmiennej stopy procentowej na stałą stopę procentową lub okresowo stałą stopę procentową – dotyczy to również umów kredytowych zawartych przed wejściem w życie niniejszej Rekomendacji. Rekomendacja wskazuje jednocześnie, że bank powinien przygotować się organizacyjnie do obsługi składanych przez klientów wniosków o zmianę formuły oprocentowania kredytu, jak również uwzględnia możliwość sukcesywnego informowania kolejnych grup klientów o możliwości zmiany formuły oprocentowania kredytu w przypadku, gdy bank przewiduje, że nie będzie w stanie obsłużyć wszystkich spodziewanych wniosków. 

Ponadto, znowelizowana Rekomendacja S wprowadza postanowienia dotyczące kredytów z opcją zwolnienia ze zobowiązania wobec banku z tytułu ekspozycji kredytowej zabezpieczonej hipotecznie na nieruchomości mieszkalnej w przypadku przeniesienia przez kredytobiorcę na bank własności do kredytowanej nieruchomości, określanych dalej jako kredyty z opcją „klucz za dług”. 

Ze względu na szczególny charakter należności hipotecznych, z zakresu Rekomendacji wyłączone są ekspozycje kredytowe finansujące nieruchomości, które nie są zabezpieczone hipotecznie. Postanowienia Rekomendacji odnoszące się do kredytu zabezpieczonego hipotecznie mają zastosowanie także do pożyczki, dla której ustanowiono takie zabezpieczenie. 

W Rekomendacji uwzględniono rekomendacje i zalecenia dotyczące kredytowania w walutach obcych, wydane przez Europejską Radę ds. Ryzyka Systemowego (ang. ESRB), Narodowy Bank Polski, Bazylejski Komitet ds. Nadzoru Bankowego, jak też przez inne organizacje i ciała kolegialne odpowiedzialne za kwestie stabilności systemu finansowego w skali międzynarodowej. Podczas projektowania zmian regulacyjnych, dokonano również przeglądu rozwiązań regulacyjnych oraz praktyki międzynarodowej z tego zakresu i niektóre z tych rozwiązań uwzględniono przy opracowaniu ostatecznego kształtu Rekomendacji. 

Jednym z celów regulacyjnych jest dążenie do uzyskania wysokiej jakości portfeli kredytowych budowanych przez banki. 

W kontekście ryzyka związanego z portfelem ekspozycji kredytowych zabezpieczonych hipotecznie należy mieć na uwadze: 

- ograniczoną płynność na rynku nieruchomości, w tym możliwość dochodzenia roszczeń z danego rodzaju nieruchomości w trybie przymusowym, co rodzi obawy o skuteczność realizacji zabezpieczeń oraz jej ewentualny wpływ na sytuację na rynku nieruchomości, 

2 

- konieczność dalszych prac ukierunkowanych na rozwój baz danych o rynku nieruchomości, 

- umiarkowane doświadczenia uczestników tego rynku w Polsce. 

Rekomendacja zwraca szczególną uwagę na kwestie odnoszące się do kredytów zabezpieczonych hipotecznie oprocentowanych stałą stopą procentową i okresowo stałą stopą procentową. 

Jak to wskazano w Rekomendacji 1.9, oczekiwaniem nadzoru jest, aby bank w ofercie kredytów zabezpieczonych hipotecznie na nieruchomościach mieszkalnych dla klientów detalicznych posiadał kredyty zabezpieczone hipotecznie oprocentowane stałą stopą procentową lub okresowo stałą stopą procentową. Należy przy tym podkreślić, że taka oferta powinna odnosić się każdorazowo do całej kwoty kredytu, o który ubiega się klient. 

Pozostałe postanowienia Rekomendacji S odnoszące się do kredytów zabezpieczonych hipotecznie oprocentowanych stałą stopą procentową lub okresowo stałą stopą procentową należy stosować z uwzględnieniem Rekomendacji 1.9. Dopuszczalne jest, aby bank oferował wyłącznie kredyty zabezpieczone hipotecznie oprocentowane stałą stopą procentową lub okresowo stałą stopą procentową. Decyzje dotyczące oferowania poszczególnych rodzajów produktów powinny uwzględniać apetyt na ryzyko banku. 

Jednocześnie należy zwrócić uwagę nie tylko na poziom wiedzy klientów, ale także ich potrzeby. Zgodnie z przepisami ustawy z dnia 16 lutego 2007 r. o ochronie konkurencji i konsumentów (Dz. U. z 2021 r. poz. 275, z późn. zm.), przez praktykę naruszającą zbiorowe interesy konsumentów rozumie się m.in. proponowanie konsumentom nabycia usług finansowych, które nie odpowiadają potrzebom tych konsumentów ustalonym z uwzględnieniem dostępnych bankowi informacji w zakresie cech tych konsumentów lub proponowanie nabycia tych usług w sposób nieadekwatny do ich charakteru. 

Oczekuje się, że banki powinny dokonywać oceny swoich produktów pod kątem ich przydatności dla określonych grup konsumentów i kierować je do grup, dla których dany produkt jest rzeczywiście przeznaczony, w sposób niewprowadzający w błąd, zgodny z dobrymi obyczajami. Najistotniejsze elementy wprowadzone w znowelizowanej Rekomendacji dotyczą: 

- wskazania, że banki powinny posiadać wśród kredytów zabezpieczonych hipotecznie na nieruchomościach mieszkalnych dla klientów detalicznych, również kredyty zabezpieczone hipotecznie oprocentowane stałą stopą procentową lub okresowo stałą stopą procentową (oznacza to, że możliwe jest oferowanie obydwu tych rodzajów kredytów) oraz umożliwiać klientom zmianę formuły oprocentowania kredytu zabezpieczonego hipotecznie ze zmiennej stopy procentowej na stałą stopę procentową lub okresowo stałą stopę procentową, 

- konieczności wyraźnego wskazania w polityce zarządzania ryzykiem portfela ekspozycji kredytowych zabezpieczonych hipotecznie, które spośród wymienionych kategorii kredytów zabezpieczonych hipotecznie bank będzie oferować klientom: oprocentowane zmienną stopą procentową, stałą stopą procentową lub też okresowo stałą stopą procentową, a także z opcją „klucz za dług”, wraz ze wskazaniem grup klientów, którym mogą być oferowane poszczególne kategorie produktów lub kryteriów, które powinny spełniać grupy klientów, 

- konieczności uwzględnienia specyfiki wybranych przez bank produktów w polityce zarządzania ryzykiem portfela ekspozycji kredytowych zabezpieczonych hipotecznie, 

3 

- sposobu informowania o oferowanych przez bank różnych rodzajach kredytów oraz zakresu przekazywanych klientom informacji dotyczących specyfiki oferowanych produktów, 

- konieczności prowadzenia szerokiej akcji edukacyjnej i informacyjnej, przedstawiającej cechy tych kredytów, zwłaszcza związanych z nimi czynników ryzyka, z uwzględnieniem specyfiki poszczególnych rodzajów oferowanych produktów – istotne jest, aby oferta poszczególnych rodzajów kredytów była przedstawiana w sposób rzetelny, czytelny oraz zrozumiały dla klienta. 

Bank, najpóźniej w określonym przez KNF terminie na wprowadzenie postanowień znowelizowanej Rekomendacji, powinien poinformować KNF, które spośród wymienionych kategorii kredytów zabezpieczonych hipotecznie będzie oferować klientom: oprocentowane zmienną stopą procentową, stałą stopą procentową lub też okresowo stałą stopą procentową, a także z opcją „klucz za dług”. Bank powinien niezwłocznie informować KNF o wprowadzanych zmianach w tym zakresie. 

Należy w tym miejscu podkreślić, że kredyty z opcją „klucz za dług” mogą mieć różne konstrukcje oraz w zależności od ich rodzaju, mogą różnić się pod względem ceny. Rekomendacja nie wyróżnia żadnego rodzaju kredytów z tej kategorii, a jedynie określa zasady zarządzania ich ryzykiem. 

Należy równocześnie wskazać, że z uwagi na szczególny charakter kredytów z opcją „klucz za dług” oraz potrzebę zapewnienia – w celu ograniczenia ryzyka systemowego – bezpiecznych zasad zarządzania ryzykiem związanym z tymi kredytami, we wszystkich obszarach objętych Rekomendacją – począwszy od rekomendacji dotyczących zarządu i rady nadzorczej, po rekomendacje dotyczące relacji z klientami – zostały wprowadzone szczegółowe uregulowania dotyczące kredytów z opcją „klucz za dług”. Banki oferujące kredyty z opcją „klucz za dług” powinny się w każdym przypadku stosować się do – odnoszących się do nich – postanowień Rekomendacji 1, 1.4.b, 1.10, 1.15, 1.17, 4.1, 4.2, 8.13, 12.2.c, 12.4, 12.6, 14.15, 15.6, 20.3, 20.5, 23.8, 25.2, 25.3, 25.4. 

W odniesieniu do kredytów udzielanych – w ramach uczestnictwa banku w rządowym programie związanym z oferowaniem przez Bank Gospodarstwa Krajowego gwarancji dla kredytów hipotecznych bez wkładu własnego – na zasadach określonych w ustawie z dnia 1 października 2021 r. o rodzinnym kredycie mieszkaniowym (Dz. U. z 2023 r. poz. 859 i 1114) wprowadzono Rekomendację 15.5a, a także zmodyfikowano Rekomendacje 1, 1.4, 1.10, 4.1, 4.2, 8.4, 10, 10.2, 13.2, 20.3, 20.5, 22.7, 22.8, 23.8 oraz 25.3. Celem tych zmian było rozszerzenie rozwiązań Rekomendacji S na kredyty mieszkaniowe z gwarancją Banku Gospodarstwa Krajowego, w szczególności wskazanie, że w zakresie wynikającym z wyżej wymienionej ustawy odstępuje się od zasady rekomendowania bankom żądania wkładu własnego oraz niekredytowania pełnej wartości nieruchomości stanowiącej przedmiot zabezpieczenia. Przyjęto też zasadę, że także w przypadku gwarantowanego kredytu mieszkaniowego wartość wskaźnika LtV nie powinna przekraczać w momencie uruchomienia kredytu poziomu 100% i wprowadzono rozwiązania 

4 

dotyczące dodatkowego zabezpieczenia analogiczne do już obowiązujących w niniejszej Rekomendacji.[1)] 

## **Obszary objęte Rekomendacją** 

Wszystkie rekomendacje odnoszą się do ekspozycji kredytowych zabezpieczonych hipotecznie i dotyczą następujących obszarów: 

1. zarząd i rada nadzorcza, 

2. identyfikacja, pomiar i ocena ryzyka ekspozycji kredytowych zabezpieczonych hipotecznie, 

3. zabezpieczenia, 

4. monitorowanie i raportowanie w zakresie ryzyka ekspozycji kredytowych zabezpieczonych hipotecznie, 

5. system kontroli wewnętrznej, 

6. relacje z klientami. 

Za pośrednictwem poszczególnych rekomendacji, KNF przedstawia sposób prowadzenia przez bank działalności w tych przypadkach, gdy przepisy prawa nie regulują tego lub czynią to w sposób niedookreślony, a istnieją przesłanki dla ukształtowania dobrej praktyki rynkowej w obszarze ekspozycji kredytowych zabezpieczonych hipotecznie. Rekomendacje stanowią ramy dla poprawnej identyfikacji, nadzoru i zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie; są zbiorem zaleceń w stosunku do wewnętrznych systemów kontroli, które pośrednio i bezpośrednio powinny zapewniać integrację rekomendacji w ramach wszystkich procesów związanych z ekspozycjami kredytowymi zabezpieczonymi hipotecznie. 

Rekomendacja S przewiduje, iż proces kredytowania w zakresie ekspozycji kredytowych zabezpieczonych hipotecznie będzie wynikał z zasad polityki opracowanych przez bank i zatwierdzonych przez zarząd banku, a cały proces będzie podlegał nadzorowi ze strony rady nadzorczej banku. 

Ze względu na wielkość zgromadzonych aktywów, prowadzoną politykę, doświadczenie oraz stopień konkurencji na danym rynku, wartość, jakość i struktura portfela ekspozycji kredytowych poszczególnych banków znacznie się różnią. Polityka kredytowa banków powinna być zatem wypadkową regulacji i limitów ustalonych przez władze nadzorcze oraz wewnątrzbankowych standardów. 

Rekomendacje nie wyczerpują zagadnień ujętych bezpośrednio w innych regulacjach, takich jak: wymogi kapitałowe, ryzyko kursowe, ryzyko koncentracji, ryzyko prawne i ryzyko stopy 

1) Akapit dodany przez § 1 pkt 1 uchwały nr 242/2023 Komisji Nadzoru Finansowego z dnia 19 czerwca 2023 r. zmieniającej uchwałę w sprawie wydania Rekomendacji S dotyczącej dobrych praktyk w zakresie zarządzania ekspozycjami kredytowymi zabezpieczonymi hipotecznie (Dz. Urz. KNF poz. 14), która weszła w życie z dniem 20 czerwca 2023 r. 

5 

procentowej ponoszone przez bank, płynność itp. Kwestie te zostały ujęte tylko w zakresie niezbędnym dla stosowania danej rekomendacji. 

## **Zakres stosowania** 

Rekomendacja S odnosi się do wszystkich banków objętych przepisami prawa polskiego oraz – we wskazanym poniżej zakresie – do oddziałów instytucji kredytowych w Polsce. W odniesieniu do niektórych banków, ze względu na ich specyfikę, skalę działalności oraz możliwość generowania ryzyka systemowego, Rekomendacja wprowadza dodatkowe wymogi. Przypadki te dotyczą banków, dla których udział portfela ekspozycji kredytowych zabezpieczonych hipotecznie jest nie mniejszy niż 2% wartości ekspozycji kredytowych zabezpieczonych hipotecznie dla całego sektora bankowego w Polsce[2)] . Ze względu na odmienność kredytów zabezpieczonych hipotecznie na nieruchomościach mieszkalnych i komercyjnych banki analizują swój udział w rynku dla każdego z tych dwóch portfeli oddzielnie. Na potrzeby Rekomendacji, banki te zostały określone jako banki istotnie zaangażowane. Bank powinien raz do roku określać swój udział w rynku na podstawie publikowanych przez KNF danych dla całego rynku według stanu na koniec roku[3)] . 

Z wyłączeniem tych obszarów, gdzie ze względu na specyfikę działalności, przyjęto odmienne podejście do poszczególnych rodzajów banków, wszystkie rekomendacje odnoszą się bezpośrednio do banków uniwersalnych, banków spółdzielczych oraz banków hipotecznych, o ile zakres rekomendacji nie został odrębnie uregulowany ustawą o listach zastawnych i bankach hipotecznych oraz aktami wykonawczymi wydanymi na jej podstawie. 

Należy odrębnie wskazać na zagadnienie oceny zdolności kredytowej przy przenoszeniu wierzytelności zabezpieczonych hipotecznie, w szczególności przenoszenia portfela takich wierzytelności do banku hipotecznego. 

W odniesieniu do tych przypadków, banki powinny kierować się mającymi zastosowanie przepisami ustawowymi. 

Z uwagi na interes klientów (zapewnienie możliwie szerokiego dostępu do kredytów zabezpieczonych hipotecznie oprocentowanych stałą stopą procentową lub okresowo stałą stopą procentową), a równocześnie zgodnie z zasadą proporcjonalności, w zakresie rekomendacji dotyczących oferowania kredytów zabezpieczonych hipotecznie oprocentowanych stałą stopą procentową lub okresowo stałą stopą procentową, oczekiwaniem nadzoru jest, aby banki zrzeszające oraz niezrzeszone banki spółdzielcze posiadały takie kredyty w ofercie kredytów zabezpieczonych hipotecznie na nieruchomościach mieszkalnych. 

Banki zrzeszające powinny także udostępniać te produkty zrzeszonym bankom spółdzielczym, tak aby miały one możliwość oferowania, w imieniu i na rachunek banku zrzeszającego, swoim 

> 2) Określając to kryterium kierowano się pojęciem „banku istotnego” zdefiniowanym w art. 4 pkt 35 ustawy – Prawo bankowe, który wskazuje – w ramach kryteriów odnoszących się do udziału banku odpowiednio w aktywach, depozytach lub funduszach własnych sektora bankowego – na poziom nie mniejszy niż 2%. 

> 3 ) Dane są publikowane okresowo przez KNF, dane na koniec roku publikowane są w terminie do 15 lutego kolejnego roku. 

6 

klientom kredytów zabezpieczonych hipotecznie oprocentowanych stałą stopą procentową lub okresowo stałą stopą procentową. 

Należy podkreślić, że w takiej sytuacji banki zrzeszające pozostają w pełni odpowiedzialne za zarządzanie ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie, w tym: 

- określenie wewnętrznych limitów ograniczających ryzyko kredytowe odnoszących się do tych ekspozycji, 

- określenie docelowych poziomów udziału ekspozycji kredytowych zabezpieczonych hipotecznie oprocentowanych zmienną stopą procentową, stałą stopą procentową i okresowo stałą stopą procentową w portfelu kredytów zabezpieczonych hipotecznie oraz terminu osiągnięcia tych poziomów, 

- ocenę zdolności kredytowej klientów. 

Niezależnie od tego, banki zrzeszone mogą też samodzielnie oferować takie kredyty, z zachowaniem zasad kontroli ryzyka obowiązujących w systemie ochrony, którego są uczestnikami. 

W zakresie ekspozycji kredytowych zabezpieczonych hipotecznie na nieruchomościach mieszkalnych, banki powinny stosować wszystkie postanowienia Rekomendacji (z wyłączeniem Rekomendacji 1.5, 8.18-8.20, 15.7 oraz 22.11). W zakresie ekspozycji kredytowych zabezpieczonych hipotecznie na nieruchomościach komercyjnych, banki zobowiązane są w każdym przypadku stosować się do postanowień Rekomendacji 1-5 (z wyłączeniem Rekomendacji 1.7, 1.23.c oraz 1.24), 8.18-8.20, 15.7 i 22.11. W odniesieniu do pozostałych zagadnień, banki mogą samodzielnie opracować rozwiązania alternatywne, jednakże spójne z celami Rekomendacji S, w zakresie w jakim mogą wykazać, że nie jest możliwe bezpośrednie stosowanie się do postanowień tych rekomendacji z uwagi na specyfikę portfela banku. 

W treści Rekomendacji zostały wyróżnione dwie kategorie nieruchomości komercyjnych: przychodowe i pozostałe. Podział ten został wprowadzony ze względu na odmienny charakter drugiej z wymienionych kategorii. W odniesieniu do ekspozycji zabezpieczonych hipotecznie na pozostałych nieruchomościach komercyjnych i finansujących te nieruchomości, nie jest konieczne stosowanie postanowień Rekomendacji 15.7 oraz 17.2. 

Należy wskazać, że korzystanie z tego wyłączenia nie może prowadzić do sytuacji pozornego określania przeznaczenia nieruchomości, gdy ostateczne przeznaczenie nieruchomości nie pozwalałoby na takie wyłączenie. 

Na banki istotnie zaangażowane w ekspozycje kredytowe zabezpieczone hipotecznie, nałożone zostały dodatkowe wymogi określone w opisach następujących rekomendacji: Rekomendacja 1.6, 4.1, 11.4, 14.9, 16.2, 17.1, 20.4, 20.5 oraz 23.7. 

W przypadku banków spółdzielczych i banków zrzeszających działających w systemie ochrony, oczekiwaniem nadzoru jest, aby postanowienia dotyczące przyjmowanej polityki były opracowywane przy wsparciu jednostek zarządzających systemami ochrony. W przypadku banku spółdzielczego funkcjonującego w zrzeszeniu, lecz niebędącego uczestnikiem systemu ochrony, oczekiwaniem nadzoru jest, aby postanowienia dotyczące przyjmowanej polityki były opracowywane przy wsparciu banku zrzeszającego. Założenia polityki winny uwzględniać indywidualną specyfikę i profil ryzyka każdego banku oraz zasadę proporcjonalności. O zakresie i stopniu zaawansowania przyjmowanych procedur powinna decydować skala działalności. 

7 

Proces tworzenia regulacji wewnętrznych w banku spółdzielczym, pomimo aktywnej roli jednostki zarządzającej systemem ochrony lub banku zrzeszającego, nie może stać w sprzeczności ze zdefiniowanym w poszczególnych rekomendacjach zakresem obowiązków i odpowiedzialnością statutowych organów zrzeszonych banków spółdzielczych. 

Realizując zasadę proporcjonalności w odniesieniu do banków spółdzielczych, przyjęto także rozwiązanie zakładające, że zarządy poszczególnych banków ustalać będą i zatwierdzać maksymalne poziomy wskaźnika DStI, wskaźnika LtV, wymagania w zakresie minimalnego wkładu własnego oraz zasady przeprowadzania testów warunków skrajnych, a następnie o przyjętych poziomach lub rozwiązaniach, informować będą nie tylko radę nadzorczą, ale także bank zrzeszający (w przypadku banku zrzeszonego niebędącego uczestnikiem systemu ochrony) lub jednostkę zarządzającą systemem ochrony (w przypadku banku należącego do systemu ochrony – dotyczy to także banku zrzeszającego). W przypadku, gdy bank zrzeszający lub jednostka zarządzająca systemem ochrony ustalą maksymalne poziomy wskaźnika DStI lub LtV dla zrzeszenia lub systemu ochrony, poziomy maksymalne przyjmowane przez banki zrzeszone lub uczestniczące w systemie ochrony, powinny być określane z uwzględnieniem tych ustaleń. 

W przypadku banku należącego do systemu ochrony, bank musi również zapewnić zgodność swojego podejścia z obowiązującymi w systemie ochrony jednolitymi mechanizmami monitorowania i klasyfikowania ryzyka. 

Jednostki zarządzające systemami ochrony i banki zrzeszające odpowiednio powinny wspierać zrzeszone banki spółdzielcze w zakresie opracowania narzędzi analitycznych na potrzeby pomiaru poziomu ryzyka związanego z ekspozycjami kredytowymi zabezpieczonymi hipotecznie, jak również opracowania i przeprowadzania testów warunków skrajnych. 

Jednostki zarządzające systemem ochrony powinny wspierać banki spółdzielcze w zakresie jak najsprawniejszego wdrożenia postanowień Rekomendacji. 

Należy zaznaczyć, że polityka i procedury powinny być adekwatne do skali prowadzonej działalności, stopnia złożoności struktury i terenu działania banku. Im są one większe, tym większe powinny być wymagania dotyczące przyjętych rozwiązań. Banki spółdzielcze o znacznej wielkości, w tym zwłaszcza banki o funduszach własnych przekraczających równowartość 5 mln euro (przeliczoną według średniego kursu wynikającego z tabeli kursów ogłaszanej przez Narodowy Bank Polski, obowiązującego na koniec roku poprzedzającego rok osiągnięcia określonego poziomu funduszy własnych), powinny posiadać procedury w pełni uwzględniające wymagania zawarte w rekomendacjach. 

Rekomendacja nie powiela treści skierowanych do banków wymogów dotyczących monitorowania wartości nieruchomości, które zostały określone w art. 208 Rozporządzenia Parlamentu Europejskiego i rady (UE) nr 575/2013 z dnia 26 czerwca 2013 r. _w sprawie wymogów ostrożnościowych dla instytucji kredytowych i firm inwestycyjnych zmieniającego rozporządzenie (UE) nr 648/2012_ . Postanowienia Rekomendacji dotyczące systemu kontroli wewnętrznej stosuje się odpowiednio do banków spółdzielczych, w których kontrola wewnętrzna, w rozumieniu audytu wewnętrznego wykonywana jest zgodnie z art. 10 ust. 2 ustawy – Prawo bankowe - przez jednostkę zarządzającą systemem ochrony lub – zgodnie z art. 10 ust. 1 ustawy – Prawo bankowe – może być wykonywana przez bank zrzeszający na zasadach określonych w umowie zrzeszenia. 

8 

Postanowienia Rekomendacji 19.4, która dotyczy m.in. aktualizacji bieżącego poziomu wskaźnika DStI dla poszczególnych klientów, należy stosować w szczególności do nowych umów kredytowych, tj. zawieranych po wejściu w życie Rekomendacji. Bank powinien zapewnić w umowach zawieranych z klientami możliwość uzyskania od klienta danych pozwalających na ustalenie bieżącego poziomu wskaźnika DStI. 

Rekomendacja zwraca także uwagę na istotne znaczenie tworzenia baz danych dotyczących rynku nieruchomości (zarówno wewnętrznych jak i zewnętrznych). Funkcjonowanie tego typu baz danych może być w znacznym stopniu pomocne w sporządzaniu ocen wartości zabezpieczenia na nieruchomości oraz monitorowaniu wartości nieruchomości, a tym samym sprzyjać wzrostowi jakości utrzymywanych przez banki zabezpieczeń hipotecznych. Banki powinny korzystać przy tym z baz danych, zgodnie z wytycznymi zawartymi w Rekomendacji J. 

Postanowienia Rekomendacji S, które mają na celu wyeliminowanie nadmiernego ryzyka, wprowadzają ograniczenia działalności kredytowej banków. Wynikająca stąd ich słabsza pozycja konkurencyjna wobec działających na polskim rynku podmiotów podlegających jurysdykcji państw obcych musiałaby nieuchronnie prowadzić do wzrostu ryzyka systemowego. Dlatego, kierując się zasadą dobra ogólnego, a także w celu ograniczenia ryzyka systemowego, Komisja Nadzoru Finansowego oczekuje, że oddziały instytucji kredytowych w Polsce będą w odpowiednim zakresie przestrzegać postanowień Rekomendacji S, w szczególności Rekomendacji 1, 6, 7, 8, 9, 10, 11, 12, 15, 25 oraz 27. 

W kontekście przedmiotu niniejszej Rekomendacji S, należy zwrócić szczególną uwagę na obowiązki nałożone na banki, wprowadzone ustawą z dnia 23 marca 2017 r. o kredycie hipotecznym oraz o nadzorze nad pośrednikami kredytu hipotecznego i agentami (Dz. U. z 2022 r. poz. 2245, z późn. zm.). Postanowienia Rekomendacji S mogą być zbieżne z przepisami ustawy. 

Natomiast zakres Rekomendacji S nie ogranicza się do kredytów udzielanych konsumentom i obejmuje zarówno kredyty zabezpieczone hipotecznie na nieruchomościach mieszkalnych, jak i komercyjnych. Ponadto, nawet w obszarach, w których przepisy ustawy i postanowienia Rekomendacji są ze sobą zbieżne, Rekomendacja może zawierać dodatkowe, czy też bardziej szczegółowe rozwiązania niż przepisy ustawy. Dotyczy to w szczególności postanowień Rekomendacji dotyczących relacji z klientami. Postanowienia Rekomendacji należy traktować jako uzupełniające i dopełniające przepisy ustawy i nie mogą być one interpretowane w sposób, który mógłby prowadzić do nieprzestrzegania przepisów wynikających z ustawy lub z innych powszechnie obowiązujących przepisów prawa. 

Komisja Nadzoru Finansowego oczekuje, że Rekomendacja S dotycząca dobrych praktyk w zakresie zarządzania ekspozycjami kredytowymi zabezpieczonymi hipotecznie, stanowiąca załącznik do uchwały Nr 492/2019 Komisji Nadzoru Finansowego z dnia 3 grudnia 2019 r. (Dz. Urz. KNF poz. 39,  z 2020 r. poz. 19 oraz z 2023 r. poz. 14), zostanie wprowadzona przez banki 

9 

spółdzielcze nie później niż do dnia 31 grudnia 2022 r., a przez pozostałe banki i oddziały instytucji kredytowych nie później niż do dnia 30 czerwca 2021 r.[4),5)] 

> 4) Ze zmianą wprowadzoną przez § 1 pkt 2 uchwały nr 173/2020 Komisji Nadzoru Finansowego z dnia 14 lipca 2020 r. zmieniającej uchwałę w sprawie wydania Rekomendacji S dotyczącej dobrych praktyk w zakresie zarządzania ekspozycjami kredytowymi zabezpieczonymi hipotecznie (Dz. Urz. KNF poz. 19), która weszła w życie z dniem 22 lipca 2020 r.; pierwotna data oczekiwanego przez Komisję Nadzoru Finansowego wprowadzenia Rekomendacji S przez banki inne niż banki spółdzielcze i przez oddziały instytucji kredytowych została wyznaczona na dzień 31 grudnia 2020 r. 

> 5) Zgodnie z § 2 uchwały, o której mowa w odnośniku 1, banki oraz oddziały instytucji kredytowych dostosują swoją działalność do rekomendacji S, w brzmieniu nadanym tą uchwałą,  nie później niż do dnia 1 lipca 2024 r. 

10 

## **Słowniczek stosowanych pojęć** 

1. **Apetyt na ryzyko** – bieżąca i przyszła gotowość banku do podejmowania ryzyka. 

2. **Bank istotnie zaangażowany** – bank, w którym udział portfela[6)] ekspozycji kredytowych zabezpieczonych hipotecznie jest nie mniejszy niż 2% wartości ekspozycji kredytowych zabezpieczonych hipotecznie dla całego sektora bankowego, przy czym: 

- przez bank istotnie zaangażowany w ekspozycje kredytowe zabezpieczone hipotecznie na nieruchomościach mieszkalnych należy rozumieć bank, w którym udział portfela ekspozycji kredytowych zabezpieczonych hipotecznie na nieruchomościach mieszkalnych jest nie mniejszy niż 2% wartości ekspozycji kredytowych zabezpieczonych hipotecznie na nieruchomościach mieszkalnych dla całego sektora bankowego, 

- przez bank istotnie zaangażowany w ekspozycje kredytowe zabezpieczone hipotecznie na nieruchomościach komercyjnych należy rozumieć bank, w którym udział portfela ekspozycji kredytowych zabezpieczonych hipotecznie na nieruchomościach komercyjnych jest nie mniejszy niż 2% wartości ekspozycji kredytowych zabezpieczonych hipotecznie na nieruchomościach komercyjnych dla całego sektora bankowego. 

3. **Bankowo-hipoteczna wartość nieruchomości** – wartość nieruchomości ustalona zgodnie z art. 2, pkt. 1 ustawy z dnia 29 sierpnia 1997 r. o listach zastawnych i bankach hipotecznych (Dz. U. z 2023 r. poz. 110). 

4. **Baza danych** – wystandaryzowane wewnętrzne oraz zewnętrzne zbiory danych prowadzone dla celów oceny ryzyka kredytowego przez bank oraz instytucje, o których mowa w art. 105 ust. 4 ustawy z dnia 29 sierpnia 1997 r. – Prawo bankowe. 

5. **Baza danych gospodarczych –** wystandaryzowane zbiory danych prowadzone przez biura informacji gospodarczej, o których mowa w ustawie z dnia 9 kwietnia 2010 r. o udostępnianiu informacji gospodarczych i wymianie danych gospodarczych (Dz. U. z 2023 r. poz. 528). 

6. **Baza danych o rynku nieruchomości** – wewnętrzny lub niezależny od banku wystandaryzowany system gromadzenia i przetwarzania danych, w którym gromadzone są w sposób systematyczny dane o rynku nieruchomości, obejmujące w szczególności charakterystyki nieruchomości oraz informacje dotyczące cen i wartości nieruchomości umożliwiające przeprowadzanie analiz i monitorowanie zjawisk zachodzących na rynku nieruchomości. Dane wprowadzane do bazy mogą pochodzić ze źródeł bankowych lub wiarygodnych źródeł pozabankowych. 

6) Bank określa swój udział na podstawie formularza FINREP FBN017, gdzie wielkość ekspozycji kredytowych zabezpieczonych hipotecznie na nieruchomościach mieszkalnych oznacza sumę pozycji: FBN17014, FBN17015, FBN17026, FBN17027, natomiast wielkość ekspozycji kredytowych zabezpieczonych hipotecznie na nieruchomościach komercyjnych oznacza sumę pozycji: FBN17010, FBN17011, FBN17018, FBN17019, FBN17022, FBN17023, FBN17030, FBN17031, FBN17051, FBN17054. 

11 

7. **Bufor dochodowy** – nadwyżka dochodu rozporządzalnego kredytobiorcy nad wydatkami związanymi z obsługą przez kredytobiorcę zobowiązań kredytowych. 

7a.[7)] **Bufor stopy procentowej** – zmiana poziomu stopy procentowej uwzględniana przy pomiarze i ocenie ryzyka ekspozycji kredytowych zabezpieczonych hipotecznie oprocentowanych zmienną lub okresowo stałą stopą procentową. W przypadku kredytów zabezpieczonych hipotecznie oprocentowanych okresowo stałą stopą procentową rekomenduje się ustalenie poziomu bufora na co najmniej wartość wynikającą z zastosowania poniższego wzoru: 

**==> picture [158 x 14] intentionally omitted <==**

gdzie: 

- Bx – bufor przy tenorze stałej stopy o długości x (w miesiącach) 

- T – okres zapadalności kredytu (w miesiącach) 

- x – długość tenoru stałej stopy, przy czym x = <60;T> 

- w – współczynnik korekty wykładniczej bufora wynoszący 1. 

W przypadku kredytów zabezpieczonych hipotecznie oprocentowanych zmienną stopą procentową rekomenduje się wyznaczanie bufora co najmniej raz w miesiącu. Poziom bufora powinien być wyznaczony na co najmniej wartość wynikającą z zastosowania poniższego wzoru: 

_MAX_ (5 p.p. - _SBC_ ; 2,5 p.p.) + _σ_ 

gdzie: 

_SBC_ = aktualna główna stopa procentowa właściwego banku centralnego[8][)] 

- 1,5 p.p., jeżeli odchylenie standardowe wartości głównej stopy procentowej właściwego banku centralnego za ostatnie 100 dni roboczych poprzedzających dzień wyznaczania poziomu bufora jest większe lub równe 0,5 p.p. oraz ostatnia 

- 𝜎= dostępna wartość stopy procentowej jest wyższa niż średnia z wartości stóp procentowych za ostatnie 100 dni roboczych. 

- 0 p.p., w pozostałych przypadkach. 

- { 

W przypadku kredytu zabezpieczonego hipotecznie udzielanego w ramach realizacji programu 

> 7) Dodany przez § 1 pkt 2 lit. a uchwały, o której mowa w odnośniku 1. 

> 8) W przypadku kredytów w złotym – stopa referencyjna NBP. 

12 

rządowego zakładającego dopłaty do oprocentowania kredytu, bank określa wysokość bufora stopy procentowej na poziomie przewyższającym wysokość tego bufora dla kredytu oprocentowanego okresowo stałą stopą procentową o długości tenoru stałej stopy równej okresowi, dla którego przewidziano w programie rządowym dopłaty do oprocentowania kredytu. 8. **Detaliczna ekspozycja kredytowa –** ekspozycja kredytowa wobec osoby fizycznej, udzielona na cele niezwiązane z działalnością gospodarczą, zawodową lub prowadzeniem gospodarstwa rolnego, z wyłączeniem ekspozycji kredytowej niezabezpieczonej hipotecznie. 

9. **Dochód rozporządzalny** – dochód pozostający do dyspozycji kredytobiorcy po pomniejszeniu o zobowiązania finansowe inne niż zobowiązania kredytowe, z których kredytobiorca nie może się wycofać, tj. wynikające m.in. z przepisów prawa lub mające charakter trwały i nieodwołalny (w szczególności wszelkie należne podatki, opłaty i składki, jak również zasądzone alimenty i wypłacane renty). 

10. **Ekspozycja kredytowa –** należność banku z tytułu kredytu lub pożyczki, limitu zadłużenia (w tym z tytułu karty kredytowej i obciążeniowej), nabytej wierzytelności, czeku lub weksla, zrealizowanej gwarancji, innej wierzytelności o podobnym charakterze lub udzielone zobowiązanie pozabilansowe. 

11. **Ekspozycja kredytowa zabezpieczona hipotecznie –** ekspozycja kredytowa związana z finansowaniem nieruchomości, w przypadku której zostało ustanowione zabezpieczenie w postaci hipoteki, lub hipoteka stanowi zabezpieczenie docelowe. W przypadku ekspozycji kredytowych zabezpieczonych hipotecznie na nieruchomości niezwiązanych z finansowaniem nieruchomości, za ekspozycje kredytowe zabezpieczone hipotecznie uznaje się ekspozycje kredytowe, w przypadku których: 

- 1) pierwotny okres zapadalności jest dłuższy niż trzy lata, oraz 

- 2) hipoteka jest lub będzie zabezpieczeniem dominującym. 

12. **Ekspozycja kredytowa zabezpieczona hipotecznie oprocentowana zmienną stopą procentową** – ekspozycja kredytowa zabezpieczona hipotecznie, w przypadku której stopa procentowa jest zmienna okresowo i zależy od ustalonego w momencie podpisania umowy mechanizmu zmiany, w szczególności od stosowanych na danym rynku wskaźników referencyjnych. 

13. **Ekspozycja kredytowa zabezpieczona hipotecznie oprocentowana stałą stopą procentową** – ekspozycja kredytowa zabezpieczona hipotecznie, w przypadku której stopa procentowa ma określoną w umowie kredytowej stałą wartość procentową i pozostaje niezmienna do końca trwania umowy. 

14. **Ekspozycja kredytowa zabezpieczona hipotecznie oprocentowana okresowo stałą stopą procentową –** ekspozycja kredytowa zabezpieczona hipotecznie, w przypadku której stopa procentowa ma stały poziom w pewnym okresie kredytowania, po którym jest ustalana na kolejny okres w nowej wysokości, lub zastępowana jest stopą zmienną. Okres, dla którego stopa procentowa ma stały poziom powinien wynosić minimum 5 lat. 

13 

15. **Gospodarstwo domowe** – przez gospodarstwo domowe rozumie się gospodarstwo prowadzone przez kredytobiorcę samodzielnie albo wspólnie z małżonkiem lub innymi osobami stale z nim zamieszkującymi i gospodarującymi. 

15a.[9)] **Gwarantowany kredyt mieszkaniowy** – kredyt mieszkaniowy, o którym mowa w ustawie z dnia 1 października 2021 r. o rodzinnym kredycie mieszkaniowym (Dz. U. z 2023 r. poz. 859 i 1114), przy którego udzielaniu Bank Gospodarstwa Krajowego wystawia gwarancję spłaty części kredytu. 

16. **Indywidualnie istotna ekspozycja kredytowa –** ekspozycja kredytowa, w przypadku której zmiana wartości może mieć istotny wpływ na wynik finansowy banku. Bank zobowiązany jest do określenia, które ekspozycje kredytowe są dla niego indywidualnie istotne. Kryteria wyznaczania ekspozycji indywidualnie istotnych powinny być dostosowane do profilu ryzyka banku. Niezależnie od wewnętrznych ustaleń banku, za indywidualnie istotne ekspozycje kredytowe należy uznawać ekspozycje, które przekraczają równowartość 3 mln euro lub stanowią więcej niż 5% funduszy własnych banku. 

17. **Klient detaliczny** – osoba fizyczna ubiegająca się w banku o detaliczną ekspozycję kredytową lub posiadająca w banku detaliczną ekspozycję kredytową. 

18. **Kredyt z opcją „klucz za dług”** – ekspozycja kredytowa zabezpieczona hipotecznie na kredytowanej nieruchomości mieszkalnej, w przypadku której warunki umowy przewidują możliwość skorzystania przez kredytobiorcę z opcji zwolnienia z zobowiązań wobec banku z tytułu tej ekspozycji, pod warunkiem przeniesienia przez kredytobiorcę na bank własności do kredytowanej nieruchomości. 

19. **Monitorowanie wartości nieruchomości**[10)] **–** obserwowanie przez bank zmian wartości nieruchomości, zgodnie z zasadami ograniczania ryzyka kredytowego stosowanymi dla celów obliczania wymogów kapitałowych z tytułu ryzyka kredytowego. 

20. **Nieruchomość komercyjna** – nieruchomość niebędącą nieruchomością mieszkalną. 

Wśród nieruchomości komercyjnych wyróżnia się: 

1) nieruchomości przychodowe – nieruchomości komercyjne przynoszące dochód generowany przez czynsz lub zyski z ich sprzedaży, zarówno istniejące, jak i w trakcie zagospodarowania, 

2) pozostałe nieruchomości komercyjne – nieruchomości komercyjne służące bezpośrednio do generowania zdolności wytwórczych i usługowych kredytobiorcy, będące elementem jego majątku trwałego, w szczególności o przeznaczeniu gospodarczym tj. przemysłowym, produkcyjnym, składowym, w tym w rolnictwie i leśnictwie oraz o charakterze publicznym (w szczególności: na cele transportu, łączności, energetyki, ochrony zdrowia, opieki 

> 9) Dodany przez § 1 pkt 2 lit. b uchwały, o której mowa w odnośniku 1. 

> 10) Jest to pojęcie tożsame z monitorowaniem wartości nieruchomości o którym mowa w art. 208 Rozporządzenia Parlamentu Europejskiego i rady (UE) nr 575/2013 z dnia 26 czerwca 2013 r. w sprawie wymogów ostrożnościowych dla instytucji kredytowych i firm inwestycyjnych zmieniającego rozporządzenie (UE) nr 648/2012, dopuszczającym wykorzystywanie metod statystycznych do monitorowania wartości nieruchomości i określania nieruchomości wymagających aktualizacji wyceny. 

14 

społecznej, oświaty, nauki, kultury i kultu religijnego, administracji publicznej, ochrony środowiska, obronności i bezpieczeństwa państwa, zaopatrzenia w wodę). 

21. **Nieruchomość mieszkalna** – nieruchomość przeznaczona na cele mieszkaniowe, która jest lub będzie zamieszkana lub przeznaczona pod wynajem przez właściciela (z wyłączeniem działalności gospodarczej), tj. dom albo lokal mieszkalny, stanowiący odrębną nieruchomość wraz z pomieszczeniami pomocniczymi służącymi zaspokojeniu potrzeb mieszkaniowych, bądź też wykorzystywanymi zgodnie z ich przeznaczeniem na inne cele niż mieszkalne (części składowe lokalu, tj. pomieszczenia, choćby nawet do niego bezpośrednio nie przylegały lub były położone w granicach nieruchomości gruntowej poza budynkiem, w którym wyodrębniono dany lokal, a w szczególności: piwnica, strych, komórka, garaż), działka budowlana lub jej część, przeznaczona pod budowę domu jednorodzinnego lub budynku mieszkalnego. 

22. **Ocena wartości zabezpieczenia na nieruchomości –** dokonywane przez bank oszacowanie kwoty możliwej do uzyskania ze sprzedaży na warunkach rynkowych nieruchomości stanowiącej zabezpieczenie danej ekspozycji kredytowej, aktualnej na moment udzielenia kredytu, lub na moment dokonania kolejnej wyceny, dokonane w oparciu o metody statystyczne lub na podstawie analizy rynku nieruchomości. Dokonywanej przez bank oceny wartości zabezpieczenia na nieruchomości nie należy utożsamiać ze sporządzaną przez rzeczoznawcę majątkowego wyceną nieruchomości, ze względu na inny cel tych procesów i – w konsekwencji – sposób (zasady i tryb) ich przeprowadzania. 

23. **Ocena zdolności kredytowej** – ocena czy klient będzie zdolny do spłaty zaciągniętego kredytu wraz z odsetkami w terminach określonych umową, z uwzględnieniem dwóch zasadniczych obszarów: 

- 1) analizy ilościowej – polegającej na ustaleniu wysokości i stabilności źródeł spłaty zaciągniętego kredytu, 

- 2) analizy jakościowej – polegającej na ocenie cech klienta, które mają istotny wpływ na skłonność klienta do spłaty zaciągniętego kredytu w terminach określonych w umowie. 

24. **Trwały nośnik** – materiał lub urządzenie, o którym mowa w art. 4 pkt 22 ustawy z dnia 23 marca 2017 r. o kredycie hipotecznym oraz nadzorze nad pośrednikami kredytu hipotecznego i agentami. 

25. **Walutowa ekspozycja kredytowa –** ekspozycja kredytowa denominowana lub indeksowana do waluty innej niż ta, w której klient uzyskuje dochody. 

26. **Wkład własny** – udział klienta w finansowaniu kredytowanej nieruchomości. 

27. **Wskaźnik DStI (ang. debt service to income) –** wskaźnik wyrażający stosunek całkowitych rocznych kosztów związanych z obsługą zobowiązań kredytowych i zobowiązań finansowych innych niż zobowiązania kredytowe (z których klient detaliczny nie może się wycofać, tj. wynikających m.in. z przepisów prawa lub mających charakter trwały i nieodwołalny) do całkowitego rocznego dochodu klienta detalicznego. 

15 

28. **Wskaźnik LtV (ang. loan to value) –** wskaźnik wyrażający stosunek ekspozycji kredytowej do wartości nieruchomości[11)] . 

29. **Wartość nieruchomości, wycena nieruchomości** – kategorie, o których mowa w art. 208 rozporządzenia Parlamentu Europejskiego i Rady (UE) nr 575/2013 z dnia 26 czerwca 2013 r. w sprawie wymogów ostrożnościowych dla instytucji kredytowych i firm inwestycyjnych, zmieniającego rozporządzenie (UE) nr 648/2012 (Dz. U. UE L 176 z 27.6.2013, str. 1, z późn. zm.). 

rozporządzenia Parlamentu Europejskiego i Rady (UE) nr 575/2013 z dnia 26 czerwca 

30. **Zabezpieczenie dominujące –** zabezpieczenie w postaci hipoteki, które stanowi jedyne zabezpieczenie ekspozycji lub jego udział stanowi ponad 50% pierwotnej wartości danej ekspozycji kredytowej. 

> 11) W przypadku kredytu zabezpieczonego hipotecznie na nieruchomości, która jest w trakcie budowy i kredyt ten jest wypłacany w transzach, bank może wprowadzić metodę liczenia wskaźnika LtV zgodnie z załącznikiem IV do Zalecenia Europejskiej Rady Ryzyka Systemowego z dnia 31 października 2016 r. w sprawie uzupełniania luk w danych dotyczących sektora nieruchomości (ERRS/2016/14), tzn. dokonywać obliczenia „V” za pomocą metody kosztowej lub odtworzeniowej, zaś jako „L”, przyjąć sumę wypłaconych transz. 

16 

## **Spis rekomendacji** 

## **Zarząd i rada nadzorcza** 

## _**Rekomendacja 1**_ 

Zarząd banku jest odpowiedzialny za zatwierdzenie i wprowadzenie sporządzonej w formie pisemnej polityki zarządzania ryzykiem portfela ekspozycji kredytowych zabezpieczonych hipotecznie. Polityka w tym zakresie powinna wynikać z zatwierdzonej przez radę nadzorczą strategii zarządzania ryzykiem prowadzonej działalności, w szczególności odzwierciedlać określone w strategii i zaakceptowane przez radę nadzorczą banku: apetyt na ryzyko, jak również maksymalne poziomy wskaźnika DStI oraz wskaźnika LtV. Polityka zarządzania ryzykiem portfela ekspozycji kredytowych zabezpieczonych hipotecznie powinna zawierać zasady określania maksymalnego poziomu wskaźnika DStI dla danego klienta, który bank może zaakceptować w zależności od sytuacji finansowej poszczególnych klientów. 

W przypadku banku spółdzielczego, zarząd zatwierdza maksymalne poziomy wskaźnika DStI oraz wskaźnika LtV, a następnie informuje radę nadzorczą i bank zrzeszający (w przypadku banku zrzeszonego niebędącego uczestnikiem systemu ochrony) lub jednostkę zarządzającą systemem ochrony (w przypadku banku należącego do systemu ochrony – dotyczy to także banku zrzeszającego). 

Bank powinien odpowiednio uwzględnić w swojej polityce zarządzania ryzykiem portfela ekspozycji kredytowych zabezpieczonych hipotecznie pełną posiadaną ofertę w zakresie kredytów zabezpieczonych hipotecznie, tj. zarówno kredytów zabezpieczonych hipotecznie oprocentowanych zmienną stopą procentową, jak i kredytów zabezpieczonych hipotecznie oprocentowanych stałą stopą procentową lub kredytów zabezpieczonych hipotecznie oprocentowanych okresowo stałą stopą procentową, jak również kredytów z opcją „klucz za dług”, a także gwarantowanych kredytów mieszkaniowych.[12)] 

## _**Rekomendacja 2**_ 

Zarząd banku powinien wyznaczyć osoby odpowiedzialne za wprowadzenie i realizację polityki banku w zakresie zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie. 

## _**Rekomendacja 3**_ 

Zarząd banku powinien co najmniej raz w roku dokonywać oceny przyjętej polityki w zakresie ekspozycji kredytowych zabezpieczonych hipotecznie pod względem sposobu jej stosowania oraz ewentualnej konieczności wprowadzenia zmian. Zarząd banku powinien poinformować radę nadzorczą o wynikach dokonanej oceny. 

## _**Rekomendacja 4**_ 

Rada nadzorcza, w ramach wypełniania swoich funkcji i odpowiedzialności za system zarządzania ryzykiem w banku, powinna nadzorować realizację polityki zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie. 

> 12) Zdanie w brzmieniu ustalonym przez § 1 pkt 3 lit. a uchwały, o której mowa w odnośniku 1. 

17 

## _**Rekomendacja 5**_ 

Struktura organizacyjna banku, w sposób odpowiadający skali działalności i profilowi ryzyka, powinna zapewniać rozdzielenie funkcji: 

- a) sprzedaży, 

- b) akceptacji ryzyka, 

- c) monitorowania i kontroli ryzyka 

ekspozycji kredytowych zabezpieczonych hipotecznie. 

## **Identyfikacja, pomiar i ocena ryzyka ekspozycji kredytowych zabezpieczonych hipotecznie** 

## _**Rekomendacja 6**_ 

W przypadku klientów detalicznych (lub gospodarstw domowych) uzyskujących dochód w kilku walutach, na potrzeby kalkulacji zdolności kredytowej, bank powinien założyć deprecjację o 50% innych walut niż waluta, w której kredytobiorca (lub gospodarstwo domowe) uzyskuje najwyższe dochody. 

## _**Rekomendacja 7**_ 

Bank powinien rekomendować klientom detalicznym okres spłaty zobowiązań nie dłuższy niż 25 lat. W przypadku podjęcia przez klienta decyzji o dłuższym okresie spłaty, bank nie powinien udzielić kredytu, którego okres spłaty przekraczałby 35 lat. 

## _**Rekomendacja 8**_ 

Przed podjęciem przez bank decyzji o zaangażowaniu się w ekspozycję kredytową zabezpieczoną hipotecznie, konieczna jest rzetelna i kompleksowa ocena zdolności kredytowej klienta w oparciu o przedstawione źródła spłaty zobowiązania, koszty utrzymania typowe dla danego kredytobiorcy, wszystkie zobowiązania finansowe oraz ustalony okres kredytowania. Wymogi w zakresie dostarczanych przez klientów dokumentów niezbędnych do oceny zdolności kredytowej powinny pozwalać na pełną i obiektywną ocenę zdolności kredytowej oraz ryzyka związanego z brakiem spłaty zadłużenia. 

## _**Rekomendacja 9**_ 

Zarząd banku ustala maksymalne dopuszczalne poziomy wskaźnika DStI. Poziomy wskaźnika DStI powinny być określone w zatwierdzonej przez radę nadzorczą banku strategii zarządzania ryzykiem. W Rekomendacji 1 określone są zasady dotyczące zatwierdzania i informowania o maksymalnych poziomach wskaźnika DStI przez bank spółdzielczy. 

## _**Rekomendacja 10**_[13] _**[)]**_ 

W przypadku ekspozycji kredytowej związanej z finansowaniem nieruchomości, z zastrzeżeniem przypadków udzielania przez bank gwarantowanego kredytu mieszkaniowego, bank nie powinien 

> 13) Rekomendacja w brzmieniu ustalonym przez § 1 pkt 3 lit. b uchwały, o której mowa w odnośniku 1. 

18 

kredytować pełnej wartości nieruchomości stanowiącej przedmiot zabezpieczenia i powinien żądać od kredytobiorcy wkładu własnego. 

## _**Rekomendacja 11**_ 

W ramach procesu oceny zdolności kredytowej klienta detalicznego konieczne jest każdorazowe korzystanie przez bank z zewnętrznych baz danych, w tym w szczególności międzybankowych baz danych budowanych przez instytucje, o których mowa w art. 105 ust. 4 ustawy z dnia 29 sierpnia 1997 r. – Prawo bankowe oraz z danych dostępnych w bazach danych gospodarczych. 

## _**Rekomendacja 12**_ 

Bank zaangażowany w ekspozycje kredytowe zabezpieczone hipotecznie przeprowadza testy warunków skrajnych badające wpływ czynników ze środowiska wewnętrznego i otoczenia zewnętrznego banku na ryzyko tych ekspozycji. 

## **Zabezpieczenia** 

## _**Rekomendacja 13**_ 

Bank powinien posiadać zasady, polityki i procedury w zakresie zabezpieczania hipotecznego ekspozycji kredytowych, w szczególności powinien określić sposób oraz rodzaj przyjmowanego zabezpieczenia hipotecznego. Przyjmowane zabezpieczenia powinny spełniać kryteria płynności, wartości oraz możliwości ich kontroli. 

## _**Rekomendacja 14**_ 

Bank powinien posiadać regulacje wewnętrzne pozwalające na ocenę wartości zabezpieczenia na nieruchomości, monitorowanie wartości nieruchomości oraz ocenę faktycznej możliwości wykorzystania zabezpieczenia na danej nieruchomości jako ewentualnego źródła dochodzenia swoich roszczeń. 

## _**Rekomendacja 15**_ 

Zarząd banku ustala poziomy wskaźnika LtV, w całym okresie spłaty ekspozycji. Poziomy wskaźnika LtV powinny być określone w zatwierdzonej przez radę nadzorczą banku strategii zarządzania ryzykiem. W Rekomendacji 1 określone są zasady dotyczące zatwierdzania i informowania o maksymalnych poziomach wskaźnika LtV przez bank spółdzielczy. 

## _**Rekomendacja 16**_ 

Bank powinien śledzić zmiany zachodzące na rynku nieruchomości oraz monitorować wartość nieruchomości stanowiących zabezpieczenie posiadanych przez bank ekspozycji kredytowych. 

## _**Rekomendacja 17**_ 

Bank powinien posiadać odpowiednie pisemne procedury pozwalające na podjęcie szybkich środków zaradczych na wypadek nieprzewidzianych zdarzeń skutkujących spadkiem wartości nieruchomości, na której ustanowiono zabezpieczenie w odniesieniu do ekspozycji kredytowej banku. 

19 

## **Monitorowanie i raportowanie w zakresie ryzyka ekspozycji kredytowych zabezpieczonych hipotecznie** 

## _**Rekomendacja 18**_ 

Bank powinien posiadać systemy monitorowania ekspozycji kredytowych zabezpieczonych hipotecznie, ze szczególnym uwzględnieniem procedur zapewniających spełnienie wymogów wynikających z przepisów prawa i regulacji wewnętrznych. 

## _**Rekomendacja 19**_ 

Bank powinien posiadać wewnętrzne systemy informacyjne, bazy danych oraz narzędzia analityczne, wspierające pomiar poziomu ryzyka związanego z ekspozycjami kredytowymi zabezpieczonymi hipotecznie. 

## _**Rekomendacja 20**_ 

Bank powinien posiadać zatwierdzone przez zarząd wewnętrzne limity ograniczające ryzyko kredytowe odnoszące się do całego portfela oraz poszczególnych rodzajów ekspozycji kredytowych zabezpieczonych hipotecznie. Limity te powinny odzwierciedlać zróżnicowanie ekspozycji kredytowych i przyjętych zabezpieczeń, strukturę i stabilność źródeł finansowania oraz poziom apetytu na ryzyko banku. 

## _**Rekomendacja 21**_ 

Bank powinien szczegółowo analizować i dostosowywać strukturę terminową źródeł finansowania i strukturę terminową aktywów. 

## _**Rekomendacja 22**_ 

Bank powinien na bieżąco kontrolować, czy wszystkie warunki umowy są wypełniane przez klienta oraz czy środki finansowe wypłacane przez bank wykorzystywane są zgodnie z umową. 

## _**Rekomendacja 23**_ 

Bank powinien zapewnić skuteczny system raportowania realizacji polityki zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie oraz poziomu ryzyka z tytułu tych ekspozycji, dostarczający informacji umożliwiających podjęcie działań zapewniających utrzymanie przyjętego poziomu apetytu na ryzyko. 

## **System kontroli wewnętrznej** 

## _**Rekomendacja 24**_ 

Bank powinien zapewnić, aby system kontroli wewnętrznej, funkcjonujący zgodnie z postanowieniami Rekomendacji H dotyczącej systemu kontroli wewnętrznej w bankach, obejmował działalność banku w zakresie ekspozycji kredytowych zabezpieczonych hipotecznie. 

20 

## **Relacje z klientami** 

## _**Rekomendacja 25**_ 

Bank powinien posiadać sporządzone w formie pisemnej procedury wewnętrzne określające sposób i zakres informowania każdego klienta ubiegającego się o kredyt zabezpieczony hipotecznie oraz uwzględniające wymogi w tym zakresie wynikające z przepisów ustawy o kredycie hipotecznym oraz o nadzorze nad pośrednikami kredytu hipotecznego i agentami. Bank powinien dołożyć wszelkich starań, aby przekazywane klientom informacje były zrozumiałe, jednoznaczne i czytelne. Dotyczy to informacji przedstawianych zarówno przed, w trakcie, jak i po podpisaniu umowy. Bank powinien uwzględniać poziom wiedzy klienta. 

## _**Rekomendacja 26**_ 

Bank powinien przedstawiać klientom detalicznym pełną posiadaną ofertę w zakresie kredytów zabezpieczonych hipotecznie na nieruchomościach mieszkalnych, tj. zarówno kredytów zabezpieczonych hipotecznie oprocentowanych zmienną stopą procentową, jak i kredytów zabezpieczonych hipotecznie oprocentowanych stałą stopą procentową lub kredytów zabezpieczonych hipotecznie oprocentowanych okresowo stałą stopą procentową. 

## _**Rekomendacja 27**_ 

W relacjach z klientami, w obszarze działalności związanej z ekspozycjami kredytowymi zabezpieczonymi hipotecznie bank powinien stosować zasady profesjonalizmu, rzetelności, staranności oraz najlepszej wiedzy. 

21 

## **I. Zarząd i rada nadzorcza** 

## **Rekomendacja 1** 

**Zarząd banku jest odpowiedzialny za zatwierdzenie i wprowadzenie sporządzonej w formie pisemnej polityki zarządzania ryzykiem portfela ekspozycji kredytowych zabezpieczonych hipotecznie. Polityka w tym zakresie powinna wynikać z zatwierdzonej przez radę nadzorczą strategii zarządzania ryzykiem prowadzonej działalności, w szczególności odzwierciedlać określone w strategii i zaakceptowane przez radę nadzorczą banku: apetyt na ryzyko, jak również maksymalne poziomy wskaźnika DStI oraz wskaźnika LtV. Polityka zarządzania ryzykiem portfela ekspozycji kredytowych zabezpieczonych hipotecznie powinna zawierać zasady określania maksymalnego poziomu wskaźnika DStI dla danego klienta, który bank może zaakceptować w zależności od sytuacji finansowej poszczególnych klientów.** 

**W przypadku banku spółdzielczego, zarząd zatwierdza maksymalne poziomy wskaźnika DStI oraz wskaźnika LtV, a następnie informuje radę nadzorczą i bank zrzeszający (w przypadku banku zrzeszonego niebędącego uczestnikiem systemu ochrony) lub jednostkę zarządzającą systemem ochrony (w przypadku banku należącego do systemu ochrony – dotyczy to także banku zrzeszającego).** 

**Bank powinien odpowiednio uwzględnić w swojej polityce zarządzania ryzykiem portfela ekspozycji kredytowych zabezpieczonych hipotecznie pełną posiadaną ofertę w zakresie kredytów zabezpieczonych hipotecznie, tj. zarówno kredytów zabezpieczonych hipotecznie oprocentowanych zmienną stopą procentową, jak i kredytów zabezpieczonych hipotecznie oprocentowanych stałą stopą procentową lub kredytów zabezpieczonych hipotecznie oprocentowanych okresowo stałą stopą procentową, jak również kredytów z opcją „klucz za dług”, a także gwarantowanych kredytów mieszkaniowych.**[14] **[)]** 

- 1.1. Zarząd banku powinien zdefiniować kluczowe obszary polityki zarządzania ryzykiem portfela ekspozycji kredytowych zabezpieczonych hipotecznie, które będą podlegać jego bezpośredniej kontroli. 

- 1.2. Zarząd banku powinien przypisać odpowiedzialność za realizację poszczególnych obszarów polityki zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie poszczególnym członkom zarządu. 

- 1.3. Zarząd banku może delegować funkcje związane z realizacją pozostałych (poza kluczowymi) obszarów polityki na wyznaczone przez siebie osoby. 

- 1.4. Rekomenduje się, aby elementami polityki zarządzania ekspozycjami kredytowymi zabezpieczonymi hipotecznie na nieruchomościach mieszkalnych były w szczególności: 

   - a) w zakresie identyfikacji, pomiaru i oceny ryzyka ekspozycji kredytowych zabezpieczonych hipotecznie zasady: 

14) Zdanie w brzmieniu ustalonym przez § 1 pkt 4 lit. a tiret pierwsze uchwały, o której mowa w odnośniku 1. 

22 

   - oceny zdolności kredytowej klientów, zawierające m.in. opis procesu akceptacji wniosku kredytowego oraz opis sposobu uwzględniania w ocenie zdolności kredytowej klientów, ryzyka stopy procentowej, 

   - [15)] ustalania i akceptacji założeń i parametrów przyjmowanych w procesie oceny zdolności kredytowej, w tym procentowy spadek bufora dochodowego w stosunku do aktualnego jego poziomu, a w przypadku ekspozycji kredytowych zabezpieczonych hipotecznie oprocentowanych zmienną stopą procentową oraz okresowo stałą stopą procentową, także zmianę poziomu stóp procentowych wyższą o nie mniej niż bufor stopy procentowej dla danego rodzaju ekspozycji, 

   - ustalania maksymalnego dopuszczalnego poziomu wskaźnika DStI, 

   - ustalania maksymalnego dopuszczalnego poziomu wskaźnika LtV, obejmujące w szczególności przyjęty przez bank sposób uwzględniania analiz dotyczących przewidywanego poziomu odzysków z przyjmowanych zabezpieczeń na nieruchomościach, 

   - przyjmowania wkładu własnego, w tym uwzględniania środków pochodzących 

      - z programów wsparcia rozwoju budownictwa mieszkaniowego, wynikających z przepisów prawa (np. programy rządowe i inne o podobnym charakterze), 

   - określania zakresu oraz sposobu dokumentowania informacji niezbędnej do oceny zdolności kredytowej, w tym zasady korzystania z baz danych i baz danych gospodarczych, 

   - wprowadzania, wykorzystywania i oceny efektywności statystycznych narzędzi wspierających ocenę zdolności kredytowej klientów detalicznych, 

- b) w zakresie akceptacji oraz ograniczania ryzyka ekspozycji kredytowych zabezpieczonych hipotecznie zasady: 

   - [16)] uwzględniania w procesie zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie, ryzyka wynikającego ze specyfiki produktowej tych ekspozycji (z rozróżnieniem co najmniej na ryzyko związane z ekspozycjami kredytowymi zabezpieczonymi hipotecznie oprocentowanymi zmienną stopą procentową, stałą stopą procentową i okresowo stałą stopą procentową oraz z uwzględnieniem opcji „klucz za dług”, a także gwarantowanych kredytów mieszkaniowych), 

   - określania akceptowalnego poziomu ryzyka dla poszczególnych portfeli kredytowych, 

> 15) W brzmieniu ustalonym przez § 1 pkt 4 lit. a tiret drugie podwójne tiret pierwsze uchwały, o której mowa w odnośniku 1. 

> 16) W brzmieniu ustalonym przez § 1 pkt 4 lit. a tiret drugie podwójne tiret drugie uchwały, o której mowa w odnośniku 1. 

23 

   - uwzględniania poziomu ryzyka z tytułu ekspozycji kredytowych zabezpieczonych hipotecznie w polityce cenowej banku, 

   - zabezpieczania i ograniczania ryzyka z tytułu ekspozycji kredytowych zabezpieczonych hipotecznie, w tym szczegółowe zasady ustalania i stosowania: 

      - maksymalnego poziomu portfela produktowego, 

      - maksymalnego poziomu pojedynczej ekspozycji, 

      - maksymalnego poziomu ekspozycji wobec klienta, 

      - maksymalnego poziomu wskaźnika LtV, 

   - dokonywania oceny wartości zabezpieczenia na nieruchomości, 

   - przeprowadzania testów warunków skrajnych badających wpływ zmiany warunków makroekonomicznych na możliwość spłaty przez klientów detalicznych posiadanych zobowiązań kredytowych, 

   - przeprowadzania testów warunków skrajnych badających wpływ czynników ze środowiska wewnętrznego i otoczenia zewnętrznego banku, w tym w szczególności warunków makroekonomicznych, na ryzyko ekspozycji kredytowych zabezpieczonych hipotecznie, 

   - ustalania, nadawania i przeglądu upoważnień do akceptacji ekspozycji kredytowych zabezpieczonych hipotecznie, 

- c) w zakresie monitorowania ryzyka ekspozycji kredytowych zabezpieczonych hipotecznie zasady: 

   - monitorowania przestrzegania limitów wewnętrznych dotyczących tych ekspozycji kredytowych, 

   - monitorowania portfela ekspozycji kredytowych zabezpieczonych hipotecznie, pozwalającego na identyfikację zagrożeń płynących z nadmiernej koncentracji wokół jednej z cech (np. koncentracja ze względu na typ nieruchomości, sektor gospodarki, długość okresu umowy, sposób oprocentowania), dla której wskaźniki jakościowe są znacząco gorsze, 

   - administrowania portfelem ekspozycji kredytowych, tj. gromadzenia i archiwizowania dokumentów, dotyczących wypłat kolejnych transz oraz dochodzenia roszczeń w przypadku naruszenia przez dłużnika warunków umowy, 

   - postępowania banku w przypadku przekroczenia wyznaczonych maksymalnych dopuszczalnych poziomów wskaźnika LtV, 

   - postępowania banku z ekspozycjami kredytowymi zabezpieczonymi hipotecznie w przypadku klientów o wysokim DStI i niskim buforze dochodowym. 

24 

- 1.5. W przypadku ekspozycji kredytowych zabezpieczonych hipotecznie na nieruchomościach komercyjnych, bank samodzielnie określa elementy polityki zarządzania ekspozycjami, przy czym polityka ta powinna zawierać co najmniej elementy, takie jak: 

   - a) metodologia ilościowej i jakościowej oceny zdolności kredytowej, 

   - b) procedury oraz wskazanie uczestników (lub role), zaangażowanych w proces wraz z ich zakresem odpowiedzialności, w tym zwłaszcza zasady ustalania, nadawania i przeglądu upoważnień do akceptacji ekspozycji kredytowych zabezpieczonych hipotecznie, 

   - c) opisany proces oceny wartości zabezpieczenia na nieruchomości, w tym tryb przyjmowania przez bank zabezpieczeń[17)] innych niż zabezpieczenie na nieruchomości komercyjnej, 

   - d) zasady uwzględniania w procesie zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie, ryzyka wynikającego ze specyfiki produktowej ekspozycji kredytowej zabezpieczonych hipotecznie na nieruchomościach komercyjnych, 

   - e) zasady ustalania maksymalnego dopuszczalnego poziomu wskaźnika LtV. 

- 1.6. Dodatkowymi elementami polityki zarządzania ekspozycjami kredytowymi zabezpieczonymi hipotecznie, w przypadku banków istotnie zaangażowanych w ekspozycje kredytowe zabezpieczone hipotecznie, powinny być: 

   - a) rodzaj i zakres analiz przeprowadzanych w procesie badania zdolności kredytowej oraz podstawowe założenia i parametry przyjmowane w tych analizach, 

   - b) zasady przeglądu efektywności stosowanych narzędzi wspierających ocenę zdolności kredytowej i ich zmian, 

   - c) opis i zakres stosowania, sposób wykorzystania systemów informatycznych wykorzystywanych w zarządzaniu ryzykiem ekspozycji kredytowych finansujących nieruchomości. 

- 1.7. Ustalając politykę zarządzania ryzykiem portfela detalicznych ekspozycji kredytowych zabezpieczonych hipotecznie zarząd banku powinien brać pod uwagę cykliczność procesów ekonomicznych, zmiany zachodzące w portfelu ekspozycji kredytowych zabezpieczonych hipotecznie oraz na rynku nieruchomości, jak również uwzględniać informacje z baz danych o rynku nieruchomości, bankowych baz danych oraz, w miarę możliwości z baz danych gospodarczych. Bank powinien dokonywać porównania jakości portfela detalicznych ekspozycji kredytowych zabezpieczonych hipotecznie z jakością portfela analogicznych ekspozycji kredytowych dla całego sektora bankowego w Polsce. Polityka zarządzania ryzykiem powinna być okresowo weryfikowana, niemniej jednak 

17) Pomimo stosowania innych zabezpieczeń niż nieruchomość komercyjna, bank na potrzeby Rekomendacji 15 powinien wyznaczać wskaźnik LtV zgodnie z definicją przedstawioną w słowniczku. 

25 

w dłuższej perspektywie powinna być stabilna i realizować podstawowe założenia strategii banku. 

- 1.8. Polityka banku powinna uwzględniać odmienną charakterystykę ryzyka związaną z zabezpieczeniem na nieruchomościach mieszkalnych i komercyjnych, nieruchomościach na rynku pierwotnym i wtórnym oraz potencjalnym źródłem spłaty ekspozycji kredytowej (np. z dochodów uzyskiwanych z nieruchomości). 

- 1.9. Bank w ofercie kredytów zabezpieczonych hipotecznie na nieruchomościach mieszkalnych dla klientów detalicznych powinien posiadać kredyty zabezpieczone hipotecznie oprocentowane stałą stopą procentową lub okresowo stałą stopą procentową. Bank powinien określić docelowe poziomy udziału ekspozycji kredytowych zabezpieczonych hipotecznie oprocentowanych zmienną stopą procentową, stałą stopą procentową i okresowo stałą stopą procentową w portfelu kredytów zabezpieczonych hipotecznie oraz określić termin osiągnięcia tych poziomów. 

- 1.10.[18) ] Bank w polityce zarządzania ryzykiem portfela ekspozycji kredytowych zabezpieczonych hipotecznie powinien precyzyjnie określić, które z następujących rodzajów kredytów będzie oferował: kredyty zabezpieczone hipotecznie oprocentowane zmienną stopą procentową, kredyty zabezpieczone hipotecznie oprocentowane stałą stopą procentową, kredyty zabezpieczone hipotecznie oprocentowane okresowo stałą stopą procentową, kredyty z opcją „klucz za dług”, a także gwarantowane kredyty mieszkaniowe. 

- 1.11. Rekomenduje się, aby bank oferujący kredyty zabezpieczone hipotecznie oprocentowane okresowo stałą stopą procentową, wydłużał minimalny 5-letni okres, dla którego stopa procentowa jest stała. 

- 1.12. Kredyty zabezpieczone hipotecznie oprocentowane stałą stopą procentową lub okresowo stałą stopą procentowa powinny być w szczególności oferowane w przypadku konwersji[19)] walutowej ekspozycji kredytowej, której zapadalność jest nie dłuższa niż okres obowiązywania stałej stopy. 

- 1.13. Bank powinien umożliwić klientowi zmianę formuły oprocentowania kredytu zabezpieczonego hipotecznie ze zmiennej stopy procentowej na stałą stopę procentową lub okresowo stałą stopę procentową. Dotyczy to również umów kredytowych zawartych przed wejściem w życie niniejszej Rekomendacji. 

   - Bank powinien przygotować się organizacyjnie do obsługi składanych przez klientów wniosków o zmianę formuły oprocentowania kredytu zabezpieczonego hipotecznie ze zmiennej stopy procentowej na stałą stopę procentową lub okresowo stałą stopę procentową. 

- 1.14. Banki wprowadzając kredyty zabezpieczone hipotecznie oprocentowane stałą stopą procentową lub okresowo stałą stopą procentową, powinny uwzględniać ich specyfikę 

> 18) W brzmieniu ustalonym przez § 1 pkt 4 lit. a tiret trzecie uchwały, o której mowa w odnośniku 1. 

> 19) Konwersja oznacza działania podejmowane w celu zastąpienia waluty walutowej ekspozycji kredytowej, walutą, w której kredytobiorcy uzyskuje większość dochodów lub posiada większość środków finansowych lub innych aktywów. 

26 

w procesie zarządzania ekspozycjami kredytowymi zabezpieczonymi hipotecznie, tak aby zostały uwzględnione czynniki ryzyka wynikające z odmiennej konstrukcji tych kredytów. Polityka banku w zakresie zarządzania ryzykiem portfela ekspozycji kredytowych zabezpieczonych hipotecznie powinna więc uwzględniać odmienną charakterystykę ryzyka związaną z ekspozycjami kredytowymi zabezpieczonymi hipotecznie oprocentowanymi zmienną stopą procentową, stałą stopą procentową i okresowo stałą stopą procentową. 

- 1.14a.[20)] Zarząd banku przystępującego do uczestnictwa w realizacji programu rządowego zakładającego dopłaty do oprocentowania kredytu, na podstawie dokonanej przez bank szczegółowej oceny ryzyka, powinien przyjąć podejście do oceny zdolności kredytowej uwzględniające specyfikę programu rządowego, w tym uwzględniania wysokości rat kapitałowo-odsetkowych płaconych przez kredytobiorcę (po uwzględnieniu oszacowanej przez bank kwoty dopłat wynikających z programu rządowego) oraz ustalania poziomu bufora stopy procentowej dla tych kredytów. 

- 1.15. Banki wprowadzając kredyty z opcją „klucz za dług”, powinny uwzględniać ich specyfikę w procesie zarządzania ekspozycjami kredytowymi zabezpieczonymi hipotecznie, tak aby zostały uwzględnione czynniki ryzyka wynikające z odmiennej konstrukcji tych kredytów. W szczególności bank powinien więc brać pod uwagę, że wartość nieruchomości w momencie przeniesienia przez kredytobiorcę na bank własności do kredytowanej nieruchomości, może różnić się od wartości nieruchomości w momencie udzielania kredytu. 

Polityka banku oferującego kredyty z opcją „klucz za dług” w zakresie zarządzania ryzykiem portfela ekspozycji kredytowych zabezpieczonych hipotecznie powinna w szczególności uwzględniać: 

- a) odmienną charakterystykę ryzyka związaną z kredytami z opcją „klucz za dług”, 

- b) sposób zarządzania ryzykiem związanym z udzielaniem kredytów z opcją „klucz za dług”, w tym zarządzania nowym ryzykiem związanym ze wzrostem liczby przejmowanych nieruchomości znajdujących się w posiadaniu banku, skorelowanym z negatywną koniunkturą na rynku nieruchomości, 

- c) wskazanie komórki organizacyjnej lub osób odpowiedzialnych za monitorowanie portfela kredytów z opcją „klucz za dług”, posiadających niezbędne kwalifikacje i doświadczenie, 

- d) wskazanie, że kredyty z opcją „klucz za dług” mogą być oferowane wyłącznie klientom o dochodach wyższych od przeciętnego poziomu wynagrodzeń w gospodarce lub danym regionie zamieszkania oraz spełniającym kryteria określone w Rekomendacji 8.13, 

- e) wskazanie, że maksymalna dopuszczalna wartość wskaźnika DStI dla kredytów z opcją „klucz za dług”, powinna być nie wyższa niż 35%. 

> 20) Dodany przez § 1 pkt 4 lit. a tiret czwarte uchwały, o której mowa w odnośniku 1. 

27 

- 1.16. Bank określając swój apetyt na ryzyko powinien uwzględnić stopień, w jakim zamierza się angażować w ekspozycje kredytowe zabezpieczone hipotecznie oprocentowane zmienną stopą procentową, stałą stopą procentową i okresowo stałą stopą procentową. Należy przy tym przeprowadzić szczegółową analizę korzyści i ryzyka z nim związanego, w tym również w porównaniu z kredytami zabezpieczonymi hipotecznie oprocentowanymi zmienną stopą procentową. 

- 1.17. Bank oferujący kredyty z opcją „klucz za dług” powinien określić maksymalny udział tych kredytów w portfelu kredytów hipotecznych. 

- 1.18. Zarząd banku, powinien otrzymywać regularne informacje umożliwiające monitorowanie szybkości/poziomu nadpłat kredytów zabezpieczonych hipotecznie oprocentowanych zmienną stopą procentową oraz stałą stopą procentową lub okresowo stałą stopą procentową (prepayment speed). 

- 1.19. W terminie nie dłuższym niż 3 lata od daty wejścia w życie niniejszej Rekomendacji lub daty rozpoczęcia udzielania kredytów, o których mowa w Rekomendacji 1.16, bank powinien rozpocząć szacowanie szybkości/poziomu nadpłat kredytów, wdrożyć do stosowania tzw. prepayment model, tj. model dostarczający metodyki opisu wcześniejszych spłat, opracowany na podstawie informacji, o których mowa w Rekomendacji 1.16 oraz uwzględniać rezultaty wynikające z tego modelu w kształtowaniu ceny produktów oraz zarządzaniu zabezpieczeniem pozycji stopy procentowej. 

- 1.20. Podstawą prowadzenia działalności w obszarze związanym z ekspozycjami kredytowymi zabezpieczonymi hipotecznie powinny być opracowane i wprowadzone przez bank, w formie pisemnej, procedury dotyczące zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie (tj. identyfikacji, pomiaru, monitorowania, kontroli oraz raportowania tego ryzyka). Procedury wewnętrzne powinny być zgodne z przepisami prawa, zdefiniowane zgodnie ze standardami wewnętrznymi oraz odpowiadać charakterowi i profilowi prowadzonej przez bank działalności. Procedury wewnętrzne powinny uwzględniać m.in. skalę, obszar działalności oraz zaawansowanie techniczne i organizacyjne banku. 

- 1.21. Polityka banku dotycząca zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie powinna w szczególności określać kluczowe założenia w odniesieniu do procedur stosowanych w przypadku zagrożonych ekspozycji kredytowych oraz ekspozycji kredytowych z utratą wartości. Wewnętrzne procesy kontroli powinny umożliwiać wczesną identyfikację ekspozycji kredytowych, których jakość zaczyna się pogarszać. Odpowiedzialność za realizację tych zadań powinna spocząć na komórce organizacyjnej banku niezależnej od komórek zajmujących się analizą kredytową i podejmowaniem decyzji o udzieleniu kredytu. 

- 1.22. Bank powinien posiadać politykę pozyskiwania długoterminowych źródeł finansowania, zapewniającą stabilne zarządzanie ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie. 

- 1.23. Opracowane przez bank procedury powinny m.in. określać tryb i metody: 

28 

- a) angażowania się banku w ekspozycje kredytowe zabezpieczone hipotecznie, w tym zadania, obowiązki, kompetencje oraz zakres odpowiedzialności, związane z procesem oceny zdolności kredytowej oraz podejmowania decyzji o zaangażowaniu się banku, jak również stosowanego przez bank podejścia względem nietypowych ekspozycji kredytowych, m.in. ekspozycji o niestandardowych harmonogramach spłat, w tym „balonowych” harmonogramach spłat (np. gdy określona część kapitału spłacana jest jednorazowo na koniec okresu kredytowania), 

- b) oceny i monitorowania zdolności kredytowej klienta, 

- c) informowania klientów o ponoszonym ryzyku (w tym ryzyku stóp procentowych oraz ryzyku walutowym) oraz całkowitych kosztach kredytu w zależności od długości okresu kredytowania i wysokości wkładu własnego, a także od zasad jego oprocentowania (stopą zmienną, stałą lub okresowo stałą), 

- d) dokumentowania danych wykorzystywanych w procesie oceny zdolności kredytowej, 

- e) korzystania z narzędzi wspierających proces oceny zdolności kredytowej, 

- f) zabezpieczania ekspozycji i monitorowania wartości nieruchomości, 

- g) wypłaty środków na finansowanie nieruchomości, 

- h) prowadzenia monitoringu spłat, restrukturyzacji i windykacji oraz spisywania należności, 

- i) dokonywania zmian warunków umów kredytowych (zarówno na wniosek klienta, jak i z inicjatywy banku) w zakresie wynikającym z obowiązujących przepisów, 

- j) refinansowania ekspozycji kredytowych zabezpieczonych hipotecznie wynikających z innych umów, 

- k) monitorowania procesu zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie, ze szczególnym uwzględnieniem procedur zapewniających spełnienie wymogów określonych w przepisach prawa oraz regulacjach wewnętrznych, 

- l) raportowania (w tym zakres, częstotliwość, odbiorców raportów, komórki odpowiedzialne za ich sporządzenie) w obszarze procesu akceptacji, skuteczności stosowanych zasad oceny zdolności kredytowej oraz ich składowych, przestrzegania limitów, jakości portfeli kredytowych, skuteczności monitoringu i odzyskiwania należności, skuteczności zabezpieczeń, poziomu strat kredytowych, 

- m) wykorzystywania (w tym opis, zakres i sposób wykorzystania) systemów informatycznych stosowanych w zarządzaniu ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie, 

- n) przeprowadzania testów warunków skrajnych. 

Pozostałe obszary, w których wymagane jest opracowanie pisemnych procedur wewnętrznych, wskazane zostały w poszczególnych rekomendacjach. 

29 

- 1.24. Bank zaangażowany w ekspozycje kredytowe zabezpieczone hipotecznie, w ramach procesów tworzenia swoich procedur, powinien wykorzystywać informacje z baz danych oraz z baz danych gospodarczych, m.in. w zakresie poziomu oraz historii spłat zobowiązań kredytowych klientów. Informacje te mogą być wykorzystane przez bank do sporządzania analiz w zakresie pozycji banku na tle całego sektora. 

- 1.25. Przyjęty w zakresie polityki wynagrodzeń banku, system motywacyjny pracowników zaangażowanych w proces kredytowy w obszarze ekspozycji kredytowych zabezpieczonych hipotecznie, powinien być powiązany z zarządzaniem ryzykiem poprzez mierniki obejmujące przestrzeganie wewnętrznych regulacji mających na celu ograniczanie ryzyka oraz przestrzeganie wynikających z apetytu na ryzyko, wewnętrznych standardów kredytowych. 

## **Rekomendacja 2** 

## **Zarząd banku powinien wyznaczyć osoby odpowiedzialne za wprowadzenie i realizację polityki banku w zakresie zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie.** 

- 2.1. Osoby wyznaczone przez zarząd banku powinny być odpowiedzialne za przygotowanie, wprowadzenie i prawidłowe stosowanie procedur wewnętrznych związanych z zarządzaniem ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie. Zasady działania w ramach kluczowych obszarów polityki zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie powinny być zatwierdzone przez zarząd banku. 

- 2.2. Do podstawowych zadań osób wyznaczonych przez zarząd banku powinno ponadto należeć: 

   - a) zapewnienie zgodności procedur wewnętrznych z przyjętą przez zarząd polityką, 

   - b) określenie zakresu zadań, obowiązków i kontroli oraz odpowiedzialności poszczególnych pracowników, 

   - c) zapewnienie okresowej, niezależnej kontroli przyjętych procedur wewnętrznych oraz sposobu ich realizacji. 

- 2.3. Przyjęte procedury dotyczące zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie powinny być w określonym przez bank trybie i terminie przedstawione pracownikom banku zaangażowanym w ten proces. Wyznaczone przez zarząd osoby powinny zapewnić zapoznanie się i zrozumienie przez pracowników stosowanych procedur oraz zapewnić kontrolę prawidłowości ich realizacji. 

## **Rekomendacja 3** 

## **Zarząd banku powinien co najmniej raz w roku dokonywać oceny przyjętej polityki w zakresie ekspozycji kredytowych zabezpieczonych hipotecznie pod względem sposobu jej** 

30 

## **stosowania oraz ewentualnej konieczności wprowadzenia zmian. Zarząd banku powinien poinformować radę nadzorczą o wynikach dokonanej oceny.** 

- 3.1. Ocena przyjętej polityki zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie powinna w szczególności obejmować sprawdzenie prawidłowości prowadzonej działalności oraz badanie rzetelności składanych sprawozdań i informacji. 

## **Rekomendacja 4** 

## **Rada nadzorcza, w ramach wypełniania swoich funkcji i odpowiedzialności za system zarządzania ryzykiem w banku, powinna nadzorować realizację polityki zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie.** 

- 4.1. Rada nadzorcza powinna otrzymywać nie rzadziej niż raz na rok, a w przypadku banku istotnie zaangażowanego, nie rzadziej niż raz na pół roku, raporty o poziomie ponoszonego przez bank ryzyka z tytułu ekspozycji kredytowych zabezpieczonych hipotecznie, wykorzystaniu limitów wewnętrznych oraz jakości i skuteczności procesów kredytowych. Raport powinien odnosić się do całego portfela kredytów zabezpieczonych hipotecznie oraz do poszczególnych rodzajów udzielanych przez bank kredytów zabezpieczonych hipotecznie (oprocentowanych zmienną stopą procentową, okresowo stałą stopą procentową, stałą stopą procentową oraz kredytów z opcją „klucz za dług”, a także gwarantowanych kredytów mieszkaniowych).[21)] 

- 4.2. Rada nadzorcza powinna otrzymywać nie rzadziej niż raz na rok sprawozdania zarządu zawierające informacje o realizacji polityki zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie. Sprawozdanie powinno odnosić się do całego portfela kredytów zabezpieczonych hipotecznie oraz do poszczególnych rodzajów udzielanych przez bank kredytów zabezpieczonych hipotecznie (oprocentowanych zmienną stopą procentową, okresowo stałą stopą procentową, stałą stopą procentową oraz kredytów z opcją „klucz za dług”, a także gwarantowanych kredytów mieszkaniowych).[22)] 

## **Rekomendacja 5** 

## **Struktura organizacyjna banku, w sposób odpowiadający skali działalności i profilowi ryzyka, powinna zapewniać rozdzielenie funkcji:** 

- **a) sprzedaży,** 

- **b) akceptacji ryzyka,** 

- **c) monitorowania i kontroli ryzyka** 

## **ekspozycji kredytowych zabezpieczonych hipotecznie.** 

> 21) Zdanie drugie w brzmieniu ustalonym przez § 1 pkt 4 lit. b tiret pierwsze uchwały, o której mowa w odnośniku 

> 1. 

> 22) Zdanie drugie w brzmieniu ustalonym przez § 1 pkt 4 lit. b tiret drugie uchwały, o której mowa w odnośniku 1. 

31 

- 5.1. Powyższy podział powinien być utrzymany na wszystkich szczeblach struktury organizacyjnej banku, z wyjątkiem zarządu, na poziomie którego powinna być rozdzielona funkcja sprzedaży od funkcji akceptacji ryzyka oraz monitorowania i kontroli ryzyka. 

- 5.2. W przypadku procesów, w których wykorzystywane są w szerokim zakresie narzędzia wspierające proces oceny zdolności kredytowej (np. systemy scoringowe) realizacja tego wymogu powinna być zapewniona poprzez: 

   - a) niezależność procesów budowy i walidacji narzędzi wspierających proces akceptacji ryzyka od funkcji sprzedażowych i związanych z działalnością operacyjną, 

   - b) ograniczenie możliwości akceptacji odstępstw od wskazań narzędzi wspierających i przypisanie kompetencji w tym zakresie z zachowaniem zasady rozdzielenia funkcji związanych z działalnością operacyjną, z której wynika podejmowanie ryzyka przez bank, oraz pomiarem, monitorowaniem i kontrolowaniem ryzyka (wyłączenie komórek odpowiedzialnych za pozyskanie klientów i sprzedaż produktów). 

32 

## **II. Identyfikacja, pomiar i ocena ryzyka ekspozycji kredytowych zabezpieczonych hipotecznie** 

## **Rekomendacja 6** 

**W przypadku klientów detalicznych (lub gospodarstw domowych) uzyskujących dochód w kilku walutach, na potrzeby kalkulacji zdolności kredytowej, bank powinien założyć deprecjację o 50% innych walut niż waluta, w której kredytobiorca (lub gospodarstwo domowe) uzyskuje najwyższe dochody.** 

- 6.1. Bank powinien posiadać politykę dotyczącą przypadków zmiany waluty, w której kredytobiorca osiąga dochody w trakcie spłaty kredytu. 

## **Rekomendacja 7** 

## **Bank powinien rekomendować klientom detalicznym okres spłaty zobowiązań nie dłuższy niż 25 lat. W przypadku podjęcia przez klienta decyzji o dłuższym okresie spłaty, bank nie powinien udzielić kredytu, którego okres spłaty przekraczałby 35 lat.** 

- 7.1. Nadmiernie wydłużony okres kredytowania powoduje istotny wzrost ryzyka po stronie kredytobiorcy i banku (wydłużenie okresu kredytowania skutkuje zarówno zwiększoną wrażliwością wysokości raty spłaty na zmiany stóp procentowych jak również niskimi kwotami spłaty kapitału w znacznej części życia produktu), jak też silny wzrost łącznych kosztów ponoszonych przez kredytobiorcę. Jednocześnie uzyskany w drodze wydłużenia okresu spłaty wzrost zdolności kredytowej lub obniżenie wysokości raty spłaty są niewielkie w stosunku do wzrostu kosztów obsługi oraz skali podejmowanego ryzyka. Dlatego bank powinien rekomendować klientom detalicznym okres spłaty nie dłuższy niż 25 lat, a jednocześnie ustalić maksymalny okres spłaty kredytu na 35 lat, przy uwzględnieniu postanowień Rekomendacji 7.2. oraz 7.3. 

- 7.2. Jeśli przewidywany okres spłaty ekspozycji jest dłuższy niż 25 lat, bank powinien przyjmować w procesie oceny zdolności kredytowej okres spłaty ekspozycji wynoszący maksymalnie 25 lat, przy uwzględnieniu postanowień Rekomendacji 7.3. 

- 7.3. Przy ustalaniu długości okresu kredytowania klienta detalicznego, bank powinien uwzględnić zdolność kredytobiorcy do kreowania dochodów w całym okresie trwania umowy, zwracając szczególną uwagę na okres, w którym należy oczekiwać osiągnięcia przez kredytobiorcę wieku emerytalnego. 

## **Rekomendacja 8** 

**Przed podjęciem przez bank decyzji o zaangażowaniu się w ekspozycję kredytową zabezpieczoną hipotecznie, konieczna jest rzetelna i kompleksowa ocena zdolności kredytowej klienta w oparciu o przedstawione źródła spłaty zobowiązania, koszty utrzymania typowe dla danego kredytobiorcy, wszystkie zobowiązania finansowe oraz ustalony okres kredytowania. Wymogi w zakresie dostarczanych przez klientów** 

33 

## **dokumentów niezbędnych do oceny zdolności kredytowej powinny pozwalać na pełną i obiektywną ocenę zdolności kredytowej oraz ryzyka związanego z brakiem spłaty zadłużenia.** 

- 8.1. Bank powinien dokonać rzetelnej i w pełni obiektywnej oceny zdolności kredytowej klienta pod względem ilościowym i jakościowym, na podstawie przedstawionych źródeł spłaty, kosztów utrzymania typowych dla danego kredytobiorcy (w przypadku klientów detalicznych), wszystkich zobowiązań kredytowych i innych niż kredytowe zobowiązań finansowych, z których kredytobiorca nie może się wycofać, tj. wynikających m.in. z przepisów prawa lub mających charakter trwały i nieodwołalny (w szczególności wszelkich należnych podatków, opłat i składek, jak również zasądzonych alimentów i wypłacanych rent) oraz ustalonego okresu kredytowania, uwzględniając przy tym postanowienia Rekomendacji 8 oraz Rekomendacji 9, 10 i 11. 

- 8.2. Bank powinien weryfikować, czy pozyskiwane od klientów informacje służące do oceny zdolności kredytowej oraz oceny ryzyka ekspozycji są autentyczne, kompletne oraz zgodne ze stanem faktycznym i prawnym. W ocenie ryzyka ekspozycji kredytowej bank powinien opierać się na potwierdzonych informacjach. Bank powinien tak ustalać zakres wymaganych informacji oraz sposób ich potwierdzenia, aby umożliwić obiektywną, pełną i efektywną ich ocenę. Bank powinien wykazać, że przyjęty zakres informacji oraz sposób ich weryfikacji jest wystarczający do wykonania obiektywnej oceny zdolności kredytowej i ryzyka ekspozycji. 

- 8.3. Elementami, które w szczególności bank powinien uwzględniać w analizie ilościowej oceny zdolności kredytowej klienta detalicznego, są dochody i wydatki wszystkich wnioskodawców i poręczycieli wnioskowanej ekspozycji kredytowej zabezpieczonej hipotecznie. 

- 8.4. Bank powinien uwzględniać w analizie ilościowej dochody charakteryzujące się stabilnością w całym okresie spłaty zobowiązania kredytowego. W przypadku osiągania dochodów nieregularnych ustalenie okresu kredytowania powinno uwzględniać indywidualną ocenę poziomu i stabilności osiąganych dochodów, a w niektórych przypadkach ich cykliczność. Szczególną uwagę bank powinien poświęcić badaniu i ocenie stabilności i cykliczności dochodów w okresie spłaty kredytu w przypadku gwarantowanego kredytu mieszkaniowego, z uwagi na wyższe ryzyko w związku z dłuższym okresem utrzymywania się wysokich LtV w trakcie spłaty kredytu.[23)] 

- 8.5. W przypadku klientów detalicznych, którzy uzyskują nieregularne lub niestabilne dochody ocena zdolności kredytowej powinna prowadzić do oceny możliwości regularnej obsługi i spłaty zobowiązań. Jeżeli ocena jest pozytywna, bank może udzielić takim klientom kredytu, pomimo nieregularności lub niestabilności ich dochodów. 

- 8.6. Bank powinien uwzględniać dochód rozporządzalny w analizie ilościowej oceny zdolności kredytowej klienta detalicznego. 

23) Zdanie trzecie dodane przez § 1 pkt 5 lit. a uchwały, o której mowa w odnośniku 1. 

34 

- 8.7. W analizie ilościowej bank powinien uwzględnić ryzyko zmniejszenia się dochodu rozporządzalnego klienta (np. na skutek spadku wynagrodzenia lub wzrostu wydatków stałych) i jego wpływ na zdolność kredytową kredytobiorcy. Rekomenduje się, aby bank w tym celu stosował w procesie oceny zdolności kredytowej bufor dochodowy, zakładając jego procentowy spadek, określony w polityce zarządzania ekspozycjami kredytowymi zabezpieczonymi hipotecznie na nieruchomościach mieszkalnych. 

- 8.8. W analizie ilościowej bank powinien uwzględnić ryzyko stopy procentowej i jego wpływ na zdolność kredytową kredytobiorcy. Rekomenduje się, aby bank uwzględniał w procesie oceny zdolności kredytowej poziom stóp procentowych, określony w polityce zarządzania ekspozycjami kredytowymi zabezpieczonymi hipotecznie, zgodnie z Rekomendacją 1.4 lit. a. 

- 8.9. Bank powinien brać pod uwagę wszystkie typowe wydatki kredytobiorcy, przy czym analizując je powinien uwzględniać kwoty odpowiadające ich rzeczywistemu poziomowi, w szczególności biorąc pod uwagę liczbę osób pozostających na jego utrzymaniu, status mieszkaniowy i miejsce zamieszkania. Bank powinien weryfikować deklarowany przez klientów poziom wydatków. Weryfikacja ta powinna być oparta na obiektywnych danych dotyczących kosztów utrzymania i wydatków gospodarstw domowych. W szczególności, przyjmowane do oceny zdolności kredytowej wydatki, inne niż związane z obsługą zobowiązań kredytowych, nie powinny być niższe, niż wynikające z niezależnych i obiektywnych analiz w zakresie poziomu wydatków gospodarstw domowych. Bank powinien wykazać zasadność założeń przyjętych do weryfikacji poziomu wydatków klienta detalicznego. 

- 8.10. Przy ocenie zdolności kredytowej niedopuszczalne jest zaniżanie kosztów utrzymania w celu uzyskania wyższej zdolności kredytowej. Przy ustalaniu minimalnych kosztów utrzymania, bank powinien wykorzystywać zarówno własne dane, jak też obiektywne analizy niezależnych instytucji i ośrodków badawczych. Rekomenduje się stosowanie kosztów utrzymania gospodarstwa domowego na poziomie nie niższym od minimum socjalnego ogłoszonego przez niezależne źródło, w tym m.in. wyniki badań budżetów gospodarstw domowych opracowywane przez Główny Urząd Statystyczny. 

- 8.11. Bank nie powinien udzielać kredytu zabezpieczonego hipotecznie, w przypadku którego po opłaceniu miesięcznej raty spłaty przez gospodarstwo domowe pozostałaby na przeżycie kwota (przypadająca na każdą osobę w gospodarstwie domowym) niższa niż wynosi minimum socjalne wyliczane przez Instytut Pracy i Spraw Socjalnych. 

- 8.12. Dodatkowo bank powinien brać pod uwagę, w miarę możliwości, wszystkie wydatki gospodarstwa domowego, które mogą obciążać klienta detalicznego. 

- 8.13. Celem ograniczania ryzyka zaciągania kredytów w celach spekulacyjnych zakupów na rynku nieruchomości, bank powinien zwracać szczególną uwagę przy weryfikacji klientów ubiegających się o kredyt z opcją „klucz za dług”, czy kredytobiorcy lub osoby pozostające z nimi w gospodarstwie domowym nie posiadają innych zobowiązań kredytowych. 

35 

- 8.14. W ramach procesu oceny zdolności kredytowej klienta detalicznego, bank powinien podjąć działania, które pozwolą na uzyskanie wiarygodnych i kompletnych informacji na temat całkowitego zadłużenia wnioskodawców i poręczycieli ekspozycji kredytowej zabezpieczonej hipotecznie, zarówno wobec banków, jak i innych podmiotów niebędących bankami, a prowadzących działalność w zakresie udzielania kredytów i pożyczek. W sytuacji, gdy nie jest możliwe sprawdzenie pochodzenia środków w sposób określony w zdaniu pierwszym, bank może przyjąć od klienta detalicznego pisemne oświadczenie na temat stanu jego całkowitego zadłużenia z tytułu zaciągniętych pożyczek i kredytów. 

- 8.15. Bank powinien określić w procedurach wewnętrznych zasady uwzględniania w procesie oceny zdolności kredytowej klientów detalicznych, przyznanych tym klientom określonych produktów kredytowych, w tym również wynikających z nich limitów. 

- 8.16. Bank powinien ocenić ryzyko wzrostu wysokości zobowiązań kredytowych związane z udzielonymi przez klientów detalicznych poręczeniami (wynikające z ich wartości), uwzględniając w analizie, terminowość i okres spłaty poręczanej ekspozycji. W szczególności bank powinien uwzględniać w ocenie zdolności kredytowej potencjalne obciążenie klientów z tego tytułu, w przypadku gdy poręczana ekspozycja spłacana jest z opóźnieniami. 

- 8.17. Analiza cech jakościowych w przypadku oceny zdolności kredytowej klienta detalicznego powinna uwzględniać m.in.: 

   - a) analizę cech osobowych klienta (np. wiek, stan cywilny, liczba osób pozostających na utrzymaniu, wykształcenie, staż pracy, wykonywany zawód, zajmowane stanowisko itp.), 

   - b) analizę historii współpracy klienta z bankiem (np. historia operacji na rachunku, terminowość spłat dotychczasowych zobowiązań, korzystanie z innych produktów banku), 

- c) analizę historii kredytowej klienta w oparciu o informacje dostępne w bazach danych oraz w bazach danych gospodarczych. 

- 8.18. Analiza ilościowa zdolności kredytowej klienta niedetalicznego powinna uwzględniać np. sytuację ekonomiczno-finansową, analizę wrażliwości finansowanej inwestycji, ewentualne scenariusze alternatywne dla inwestycji, w szczególności parametry, takie jak zmiana stóp procentowych, zmiana kursów walut, wzrost kosztów inwestycji, wydłużenie okresu realizacji inwestycji, zmiany cen. 

- 8.19. W przypadku kredytów zabezpieczonych hipotecznie na nieruchomości komercyjnej, bank powinien dokonać ostrożnej oceny możliwości spłaty kredytu, w tym w szczególności oceny planu finansowego inwestycji. Bank powinien zachować ostrożne podejście w przypadku kredytu z niestandardowym (w zakresie kwot spłat poszczególnych rat i/lub ich rozłożenia w czasie) harmonogramem spłat. 

- 8.20. Analiza cech jakościowych w przypadku oceny zdolności kredytowej klienta niedetalicznego w przypadku finansowania inwestycji powinna uwzględniać m.in.: 

36 

- a) informacje dotyczące inwestycji (opis, koszty, źródła finansowania, dokumentacja kosztorysowo-projektowa z uwzględnieniem poziomu rezerw na nieprzewidziane wydatki, harmonogram inwestycji, wypełnienie wymogów administracyjnych), 

- b) informacje dotyczące struktury transakcji (status prawny kredytobiorcy, sposób wypłaty środków, zabezpieczenia, warunki umowne, informacje dotyczące założycieli spółki celowej – SPV), 

- c) informacje dotyczące rynku (ocena podaży i popytu oraz ich źródeł, cen, konkurencji), 

- d) informacje odnośnie poziomu przyjętych parametrów istotnych dla przepływów finansowych oraz przeciętnych parametrów na rynku (np. porównanie kosztu inwestycji z przeciętnymi kosztami/normatywami, porównanie poziomu czynszów, cen), 

- e) informacje o kredytobiorcy (m.in. struktura własnościowa, doświadczenie i pozycja na rynku), 

- f) informacje o innych podmiotach istotnych dla procesu inwestycyjnego, 

- g) strategię rynkową kredytobiorcy (polityka sprzedaży, marketing, grupy docelowe), 

- h) inne zidentyfikowane czynniki ryzyka i sposób ich ograniczenia oraz zgodność z polityką kredytową banku (z uwzględnieniem odstępstw od polityki). 

## **Rekomendacja 9** 

**Zarząd banku ustala maksymalne dopuszczalne poziomy wskaźnika DStI. Poziomy wskaźnika DStI powinny być określone w zatwierdzonej przez radę nadzorczą banku strategii zarządzania ryzykiem. W Rekomendacji 1 określone są zasady dotyczące zatwierdzania i informowania o maksymalnych poziomach wskaźnika DStI przez bank spółdzielczy.** 

- 9.1. Określając maksymalny dopuszczalny poziom wskaźnika DStI bank powinien uwzględniać m.in.: 

   - a) skalę oraz rodzaj prowadzonej przez bank działalności, 

   - b) apetyt na ryzyko, 

   - c) jakość portfela kredytowego banku, 

   - d) zmiany zachodzące w strukturze portfela ekspozycji kredytowych zabezpieczonych hipotecznie, 

   - e) rodzaj produktu, 

   - f) grupę klientów do których skierowanych jest dany produkt, 

   - g) długość okresu zaangażowania banku w finansowanie ekspozycji kredytowej zabezpieczonej hipotecznie, 

   - h) zmiany zachodzące w otoczeniu banku. 

37 

- 9.2. W celu ustalenia maksymalnego dopuszczalnego poziomu wskaźnika DStI, bank powinien uwzględnić analizę wydatków typowych dla poszczególnych gospodarstw domowych (ze względu na ich liczebność, region zamieszkania i inne charakterystyczne cechy) wykorzystując zarówno własne dane, jak też obiektywne analizy niezależnych instytucji i ośrodków badawczych, w tym m.in. wyniki badań budżetów gospodarstw domowych opracowywane przez GUS. 

- 9.3. W procesie oceny zdolności kredytowej klientów detalicznych, szczególną uwagę bank powinien zwracać na sytuacje, w których wskaźnik DStI przekracza 40% dla klientów o dochodach nieprzekraczających przeciętnego poziomu wynagrodzeń w danym regionie zamieszkania oraz 50% dla pozostałych klientów. Wynika to z bardzo długiego okresu spłaty większości ekspozycji kredytowych zabezpieczonych hipotecznie oraz tego, że w przypadku większości gospodarstw domowych koszty utrzymania przekraczają połowę ich dochodów netto. Bank może przekraczać te wartości, ale powinna być to świadoma akceptacja podwyższonego ryzyka tak po stronie banku, jak i klienta. W szczególności, bank powinien poinformować klienta o podwyższonym ryzyku takiego produktu oraz negatywnym wpływie na możliwość realizacji przez klienta większych wydatków lub tworzenia oszczędności. 

- 9.4. Bank powinien co najmniej raz w roku dokonywać oceny adekwatności poziomu przyjętego wskaźnika DStI. 

- 9.5. Dokumentacja banku w zakresie wskaźnika DStI powinna zawierać co najmniej: 

   - a) szczegółowy opis założeń przyjętych do ustalenia poziomu wskaźnika, 

   - b) analizę uzasadniającą przyjęty przez bank poziom wskaźnika, 

   - c) analizy poziomu ryzyka kredytowego w zależności od zmienności tego wskaźnika, 

   - d) wyniki testowania historycznego wpływu ustalonego przez bank poziomu wskaźnika na poziom ryzyka poszczególnych portfeli kredytowych banku. 

## **Rekomendacja 10** 

**W przypadku ekspozycji kredytowej związanej z finansowaniem nieruchomości, z zastrzeżeniem przypadków udzielania przez bank gwarantowanego kredytu mieszkaniowego, bank nie powinien kredytować pełnej wartości nieruchomości stanowiącej przedmiot zabezpieczenia i powinien żądać od kredytobiorcy wkładu własnego.**[24][)] 

- 10.1. Bank powinien ustalić wewnętrzne limity minimalnych wymagań w zakresie wkładu własnego, które powinny zostać zatwierdzone przez radę nadzorczą. W przypadku banku spółdzielczego, wewnętrzne limity minimalnych wymagań w zakresie wkładu własnego zatwierdza zarząd a następnie informuje radę nadzorczą i bank zrzeszający (w przypadku banku zrzeszonego niebędącego uczestnikiem systemu ochrony) lub jednostkę 

> 24) Wprowadzenie w brzmieniu ustalonym przez § 1 pkt 5 lit. b tiret pierwsze uchwały, o której mowa w odnośniku 

> 1. 

38 

zarządzającą systemem ochrony (w przypadku banku należącego do systemu ochrony – dotyczy to także banku zrzeszającego). 

Bank należący do systemu ochrony musi uzyskać od jednostki zarządzającej systemem ochrony akceptację przyjętych wewnętrznych limitów. 

- 10.2.[25)] Ustalone przez bank limity w zakresie minimalnego wkładu własnego nie powinny być sprzeczne z postanowieniami w zakresie wskaźnika LtV zawartymi w Rekomendacjach 15.5, 15.5a, 15.6 i 15.7. 

- 10.3. Na poczet wkładu własnego, bank może zaliczyć wartość nieruchomości gruntowej (niezabudowanej lub zabudowanej), na której docelowo znajdować się będzie nieruchomość stanowiąca przedmiot kredytowania. 

- 10.4. Wkład własny klienta powinien zostać wniesiony najpóźniej w momencie uruchomienia kredytu. W przypadku ekspozycji kredytowych zabezpieczonych hipotecznie wypłacanych w transzach, wkład własny może być wnoszony proporcjonalnie w odniesieniu do kwoty wypłaconych transz. 

- 10.5. Bank może dopuścić wniesienie wkładu własnego (całości lub części) w drodze realizacji programów wsparcia rozwoju budownictwa mieszkaniowego wynikających z przepisów prawa (np. programy rządowe i inne o podobnym charakterze). 

- 10.6. W przypadku uznania przez bank za wkład własny wartości nieruchomości gruntowej (niezabudowanej lub zabudowanej), na której docelowo znajdować się będzie kredytowana nieruchomość, konieczne jest zweryfikowanie czy nieruchomość ta nie jest obciążona hipoteką. W sytuacji, gdy bank ustalił, iż nieruchomość – na której docelowo znajdować się będzie kredytowana nieruchomość – jest obciążona hipoteką, bank ocenia w jakiej części wartość tej nieruchomości może zostać uznana jako wkład własny. 

- 10.7. Bank powinien upewnić się, że środki finansowe kredytobiorcy przeznaczone na wkład własny nie pochodzą z kredytu, pożyczki lub dotacji. W tym celu należy odpowiednio zastosować postanowienia rekomendacji 8.14. 

- 10.8. W przypadku nieruchomości użytkowanych w sposób mieszany tj. o przeznaczeniu mieszkalno-komercyjnym, gdy ponad 50% wartości nieruchomości stanowi wartość części ułamkowej nieruchomości o przeznaczeniu mieszkalnym, bank powinien stosować postanowienia Rekomendacji w zakresie wkładu własnego dotyczące ekspozycji kredytowych zabezpieczonych hipotecznie na nieruchomościach mieszkalnych. 

   - W przeciwnym przypadku, bank powinien stosować postanowienia Rekomendacji w zakresie wkładu własnego dotyczące ekspozycji kredytowych zabezpieczonych hipotecznie na nieruchomościach komercyjnych. 

## **Rekomendacja 11** 

## **W ramach procesu oceny zdolności kredytowej klienta detalicznego konieczne jest** 

25) W brzmieniu ustalonym przez § 1 pkt 5 lit. b tiret drugie uchwały, o której mowa w odnośniku 1. 

39 

**każdorazowe korzystanie przez bank z zewnętrznych baz danych, w tym w szczególności międzybankowych baz danych budowanych przez instytucje, o których mowa w art. 105 ust. 4 ustawy z dnia 29 sierpnia 1997 r. – Prawo bankowe oraz z danych dostępnych w bazach danych gospodarczych.** 

- 11.1. Bank powinien korzystać z międzybankowych baz danych w celu potwierdzenia wielkości wydatków klientów detalicznych na spłatę posiadanych zobowiązań oraz w celu analizy historii kredytowej klienta. 

- 11.2. Korzystając z zewnętrznych, w tym międzybankowych baz danych i baz danych gospodarczych, bank powinien ocenić ich wiarygodność. W przypadku jakichkolwiek wątpliwości w tym zakresie bank powinien dążyć do potwierdzenia otrzymanych danych z danymi z innych źródeł. 

- 11.3. Bank powinien aktywnie uczestniczyć w zasilaniu międzybankowych baz danych przekazując kompletne i aktualne informacje na temat wszystkich zobowiązań kredytowych klientów. 

- 11.4. Bank może, a bank istotnie zaangażowany w ekspozycje kredytowe zabezpieczone hipotecznie powinien, gromadzić informacje o współpracy banku z klientami w zakresie przydatnym do zarządzania ryzykiem kredytowym i operacyjnym, w szczególności historii kredytowej. Informacje te powinny wspomagać proces oceny i monitorowania zdolności kredytowej, m.in. poprzez rozwój i wykorzystanie statystycznych narzędzi wspierających ocenę zdolności kredytowej. 

- 11.5. Bank, który gromadzi informacje o współpracy banku z klientami, powinien posiadać procedury w formie pisemnej określające sposób gromadzenia i przetwarzania tych informacji, sposób kontroli kompletności i rzetelności tych informacji, weryfikacji ich wiarygodności oraz wskazujące osoby odpowiedzialne za wykonywanie poszczególnych czynności. 

## **Rekomendacja 12** 

**Bank zaangażowany w ekspozycje kredytowe zabezpieczone hipotecznie przeprowadza testy warunków skrajnych badające wpływ czynników ze środowiska wewnętrznego i otoczenia zewnętrznego banku na ryzyko tych ekspozycji.** 

- 12.1. Bank powinien posiadać sporządzone w formie pisemnej i zatwierdzone przez swoją radę nadzorczą zasady przeprowadzania testów warunków skrajnych. W przypadku banku spółdzielczego, zarząd zatwierdza zasady przeprowadzania testów warunków skrajnych, a następnie informuje radę nadzorczą i bank zrzeszający (w przypadku banku zrzeszonego niebędącego uczestnikiem systemu ochrony) lub jednostkę zarządzającą systemem ochrony (w przypadku banku należącego do systemu ochrony – dotyczy to także banku zrzeszającego). 

   - Bank należący do systemu ochrony musi następnie uzyskać od jednostki zarządzającej systemem ochrony akceptację przyjętych zasad. 

- 12.2. Testy warunków skrajnych w odniesieniu do: 

40 

   - a) ekspozycji kredytowych zabezpieczonych hipotecznie oprocentowanych zmienną stopą procentową lub okresowo stałą stopą procentową obejmują co najmniej: 

      - wpływ zmian stóp procentowych i kursów walut na adekwatność przyjętego przez bank maksymalnego poziomu wskaźnika DStI, 

      - wpływ zmian kursów walut na adekwatność przyjętego przez bank maksymalnego poziomu wskaźnika LtV, 

      - wpływ zmian stóp procentowych w szczególności na jakość portfela ekspozycji kredytowych zabezpieczonych hipotecznie oraz poziom odpisów (rezerw), 

   - b) walutowych ekspozycji kredytowych obejmują co najmniej: 

      - wpływ zmian kursów walut na jakość portfela walutowych ekspozycji kredytowych oraz poziom odpisów (rezerw), 

   - c) kredytów z opcją „klucz za dług” obejmują co najmniej: 

      - wpływ znacznego spadku cen nieruchomości na wielkość strat z portfela kredytów z opcją „klucz za dług”, w przypadku skorzystania przez kredytobiorców z opcji przeniesienia na bank własności do kredytowanej nieruchomości i jednoczesnego zwolnienia z zobowiązań wobec banku z tytułu tych ekspozycji. 

- 12.3. Co najmniej raz w roku, bank powinien analizować wpływ ryzyka kursowego zarówno na jakość portfela ekspozycji kredytowych zabezpieczonych hipotecznie, jak i adekwatność przyjętego przez bank maksymalnego poziomu wskaźnika LtV. 

- 12.4. Co najmniej raz w roku, bank zaangażowany w ekspozycje kredytowe zabezpieczone hipotecznie, powinien przeprowadzać testy warunków skrajnych w zakresie wpływu zmiany stóp procentowych na jakość portfela ekspozycji kredytowych zabezpieczonych hipotecznie. Częstsze dokonywanie testów warunków skrajnych rekomendowane jest w razie istotnych zmian warunków rynkowych. Jako wymóg minimalny rekomenduje się przeprowadzanie testów warunków skrajnych przy założeniu wzrostu stóp procentowych o 400 punktów bazowych, przy czym należy przyjąć, że wzrost poziomu stóp procentowych będzie utrzymywał się przez okres 12 miesięcy. 

   - Testy należy przeprowadzać zarówno dla całego portfela ekspozycji kredytowych zabezpieczonych hipotecznie, jak i subportfeli takich ekspozycji (co najmniej dla ekspozycji kredytowych zabezpieczonych hipotecznie oprocentowanych okresowo stałą stopą procentową oraz zmienną stopą procentową oraz kredytów z opcją „klucz za dług”). 

- 12.5. Co najmniej raz w roku, bank zaangażowany w walutowe ekspozycje kredytowe zabezpieczone hipotecznie, powinien przeprowadzać testy warunków skrajnych w zakresie wpływu ryzyka kursowego kredytobiorcy na ryzyko kredytowe ponoszone przez bank. Częstsze dokonywanie testów warunków skrajnych rekomendowane jest w razie istotnych zmian warunków rynkowych. Jako wymóg minimalny rekomenduje się przeprowadzanie testów warunków skrajnych przy założeniu spadku kursu złotego, w stosunku do poszczególnych walut obcych o większą z dwóch wartości: 

41 

a) 50%, 

- b) maksymalna roczna zmiana kursu z ostatnich 10 lat 

– przy czym należy przyjąć, że spadek kursu walutowego będzie utrzymywał się przez okres 12 miesięcy. 

12.6. Bank zaangażowany w ekspozycje kredytowe zabezpieczone hipotecznie, co najmniej raz w roku powinien przeprowadzać testy warunków skrajnych w celu oceny wpływu gwałtownej zmiany wartości nieruchomości na przewidywaną wielkość strat z portfela ekspozycji kredytowych zabezpieczonych hipotecznie. Częstsze dokonywanie testów warunków skrajnych rekomendowane jest w razie istotnych zmian warunków rynkowych. 

Testy należy przeprowadzać zarówno dla całego portfela ekspozycji kredytowych zabezpieczonych hipotecznie, jak i subportfela ekspozycji kredytowych zabezpieczonych hipotecznie z opcją „klucz za dług”. 

- 12.7. Wnioski z wymienionych powyżej testów warunków skrajnych powinny być regularnie raportowane przez zarząd radzie nadzorczej celem wykorzystania ich w ramach przeglądu i aktualizacji polityki zarządzania ekspozycjami kredytowymi banku. Rekomenduje się, aby bank przesyłał wyniki przeprowadzanych testów warunków skrajnych oraz założeń do tych testów również do Komisji Nadzoru Finansowego. 

- 12.8. W przypadku banków spółdzielczych funkcjonujących w zrzeszeniach informacje dotyczące założeń i wyników testów w tym obszarze należy przekazać przy kwestionariuszu BION. 

42 

## **III. Zabezpieczenia** 

## **Rekomendacja 13** 

**Bank powinien posiadać zasady, polityki i procedury w zakresie zabezpieczania hipotecznego ekspozycji kredytowych, w szczególności powinien określić sposób oraz rodzaj przyjmowanego zabezpieczenia hipotecznego. Przyjmowane zabezpieczenia powinny spełniać kryteria płynności, wartości oraz możliwości ich kontroli.** 

- 13.1. Podstawowym źródłem spłaty kredytu powinny być dla banku dochody kredytobiorcy, w tym z prowadzonej działalności gospodarczej. Zabezpieczenie hipoteczne ekspozycji kredytowej nie powinno zastępować lub rekompensować braku lub słabości podstawowego źródła spłaty. Przyjęcie zabezpieczenia nie powinno ograniczać lub wpływać na kompletność, rzetelność i obiektywność procesu oceny ryzyka, w tym zdolności kredytowej. 

- 13.2. Bank, przyjmując zabezpieczenie, powinien dokonać weryfikacji podstawowych kryteriów decydujących o jego skuteczności: płynności zabezpieczenia, wartości oraz dostępu i możliwości kontroli w całym okresie kredytowania. Weryfikacja tych warunków powinna być szczególnie uważnie dokonywana w przypadku gwarantowanego kredytu mieszkaniowego z uwagi na podwyższone ryzyko w związku z dłuższym okresem utrzymywania się wysokich wartości LtV w trakcie spłaty kredytu.[26)] 

- 13.3. Bank może uznać zabezpieczenie za płynne, jeśli możliwe jest jego zbycie bez istotnego obniżenia jego ceny w czasie, który nie naraża banku na zmianę wartości zabezpieczenia hipotecznego ze względu na właściwą danemu rodzajowi zabezpieczenia fluktuację cen. Bank powinien określić w swoich zasadach polityki kryteria płynności dla poszczególnych rodzajów zabezpieczeń hipotecznych: istotnej zmiany ceny i czasu zbycia zabezpieczenia. 

- 13.4. W ramach wycen nieruchomości przyjmowanych jako zabezpieczenie, przygotowywanych zarówno na zlecenie banku jak i dostarczonych przez klientów, bank powinien dokonać kontroli wiarygodności i rzetelności założeń i parametrów rynkowych przyjętych na potrzeby wyceny. Poziom parametrów przyjętych przez sporządzającego wycenę powinien być przez bank weryfikowany na podstawie dostępnych baz danych o rynku nieruchomości, katalogów branżowych, innych opracowań analitycznych i posiadanego doświadczenia. Zweryfikowana w ten sposób wartość nieruchomości przyjmowanej jako zabezpieczenie powinna stanowić punkt odniesienia dla ustalenia kwoty kredytu w przypadku detalicznych ekspozycji kredytowych (np. przy uwzględnieniu założonego poziomu wskaźnika LtV). 

- 13.5. Bank powinien zapewnić sobie możliwość kontroli zabezpieczenia hipotecznego, zabezpieczenie (w tym ubezpieczenie) od skutków zniszczenia oraz prawo do kontroli jego stanu. Bank nie powinien nakładać w tym zakresie dodatkowych obowiązków na kredytobiorcę, jeśli posiadana przez kredytobiorcę ochrona ubezpieczeniowa spełnia 

> 26) Zdanie drugie dodane przez § 1 pkt 6 lit. a tiret pierwsze uchwały, o której mowa w odnośniku 1. 

43 

określone przez bank warunki. Bank powinien przedstawić klientowi swoje wymagania odnośnie ubezpieczenia przedmiotu zabezpieczenia przed zawarciem umowy kredytowej oraz potwierdzić te warunki w umowie kredytowej. 

- 13.6. Bank analizując ryzyko związane z danym zabezpieczeniem hipotecznym powinien uwzględniać takie czynniki jak: 

   - a) rodzaj i przedmiot zabezpieczenia (w tym różnice i sposób egzekucji z zabezpieczenia), 

   - b) kolejność zaspokajania się z zabezpieczenia (m.in. kolejność hipotek, opróżnione miejsce hipoteczne), 

   - c) stan techniczny przedmiotu zabezpieczenia, 

   - d) koszty utrzymania zabezpieczenia i egzekucji z zabezpieczenia (w tym koszty ewentualnego przejęcia zabezpieczenia) 

– lub czynniki o podobnym charakterze do wskazanych. 

- 13.7. Rekomenduje się, aby szczególnej uwadze poddane były te ekspozycje, dla których ustanowione zabezpieczenie nie jest własnością danych kredytobiorców. 

- 13.8.[27)] Analizując ryzyko związane z daną nieruchomością, stanowiącą zabezpieczenie ekspozycji kredytowej, a w szczególności analizując faktyczną możliwość zaspokojenia się z danej nieruchomości, bank powinien uwzględniać wymogi prawne. Bank powinien posiadać procedury postępowania w przypadku konieczności zaspokojenia się z nieruchomości stanowiącej zabezpieczenie, które uwzględniają wymogi wynikające z obowiązujących przepisów prawa. 

## **Rekomendacja 14** 

**Bank powinien posiadać regulacje wewnętrzne pozwalające na ocenę wartości zabezpieczenia na nieruchomości, monitorowanie wartości nieruchomości oraz ocenę faktycznej możliwości wykorzystania zabezpieczenia na danej nieruchomości jako ewentualnego źródła dochodzenia swoich roszczeń.** 

- 14.1. Bank powinien określić wymagania jakościowe (w tym w zakresie aktualności oceny) stawiane źródłom informacji. 

- 14.2. Zarząd banku powinien być odpowiedzialny za przyjęcie regulacji wewnętrznych dotyczących oceny wartości zabezpieczenia na nieruchomości i monitorowania wartości nieruchomości, a osoby wyznaczone przez zarząd banku powinny odpowiadać za wprowadzenie przyjętych przez zarząd regulacji. 

- 14.3. Bank powinien określić proces oceny wartości zabezpieczenia na nieruchomości i monitorowania wartości nieruchomości oraz osoby odpowiedzialne za jego realizację. 

27) W brzmieniu ustalonym przez § 1 pkt 6 lit. a tiret drugie uchwały, o której mowa w odnośniku 1. 

44 

Osoby te powinny posiadać niezbędne kwalifikacje i doświadczenie w zakresie oceny wartości zabezpieczenia na nieruchomości. 

- 14.4. W ramach oceny wartości zabezpieczenia na nieruchomości bank powinien uwzględniać wartość zabezpieczenia hipotecznego możliwą do uzyskania podczas ewentualnego postępowania windykacyjnego, biorąc pod uwagę ograniczenia prawne, ekonomiczne (m.in. koszty zbycia zabezpieczenia) oraz inne mogące wpływać na rzeczywistą możliwość zaspokojenia się banku z przedmiotu zabezpieczenia. 

- 14.5. Bank powinien zapewnić sobie prawo do inspekcji i oceny stanu przedmiotu zabezpieczenia zarówno przez pracownika banku, jak i powołanych przez bank ekspertów w każdym momencie istnienia ekspozycji oraz pozyskiwania niezbędnych informacji w tym zakresie. 

- 14.6. Bank powinien ustalić zasady zabezpieczania ekspozycji kredytowych w okresie pomiędzy złożeniem wniosku o wpis hipoteki do księgi wieczystej, a dokonaniem wpisu (ze względu na czas tego procesu) lub kontroli inwestycji, gdy nieruchomość jest w trakcie budowy lub remontu (istotnie wpływającego na jej wartość). 

- 14.7. Bank niezależnie od ustalenia zasad oceny wartości zabezpieczenia na nieruchomości ekspozycji kredytowych powinien ustalić zasady monitorowania wartości nieruchomości, spełniające wymagania w tym zakresie przewidziane dla zabezpieczeń na nieruchomości w technikach ograniczania ryzyka kredytowego stosowanych dla celów obliczania wymogów kapitałowych z tytułu ryzyka kredytowego. 

- 14.8. Bank powinien wykorzystywać dostępne dane z wiarygodnych baz danych o rynku nieruchomości, katalogów branżowych lub obiektywnych opracowań analitycznych na potrzeby oceny wartości zabezpieczenia na nieruchomości i monitorowania wartości nieruchomości, oceny rynku nieruchomości oraz wyliczania wskaźnika LtV. Bank powinien dokonać krytycznej analizy jakości danych zawartych w bazach, katalogach i opracowaniach oraz określić zasady korzystania z tych źródeł. 

- 14.9. Proces oceny wartości zabezpieczenia na nieruchomości powinien zapewniać zachowanie niezależności i obiektywności. Osoby dokonujące oceny wartości zabezpieczenia na nieruchomości powinny być niezależne od pracowników komórek sprzedaży, a w bankach istotnie zaangażowanych w ekspozycje kredytowe zabezpieczone hipotecznie, także od pracowników komórek akceptacji ryzyka. 

- 14.10. Systemy motywacyjne osób odpowiedzialnych za oceny wartości zabezpieczeń na nieruchomości i monitorowania wartości nieruchomości powinny sprzyjać osiąganiu i zachowaniu wysokiej jakości procesu oceny zmierzającej do ustalenia wartości, jaką bank będzie w stanie odzyskać z przedmiotu zabezpieczenia. 

- 14.11. Przyjęte przez bank regulacje powinny jednoznacznie opisywać stosowane kryteria oceny i monitorowania, sposób ich stosowania oraz dokumentowania tych procesów. 

- 14.12. Procesy oceny wartości zabezpieczenia na nieruchomości i monitorowania wartości nieruchomości powinny być każdorazowo dokumentowane a ich wyniki w sposób systematyczny ewidencjonowane. 

45 

- 14.13. Bank powinien systematycznie (co najmniej raz na rok) dokonywać przeglądu skuteczności procesu oceny wartości zabezpieczenia na nieruchomości i monitorowania wartości nieruchomości i adekwatnie do wyników tego przeglądu dokonywać oceny skuteczności zasad i procedur oceny i monitorowania. 

- 14.14. W przypadku dochodzenia roszczeń z przedmiotu zabezpieczenia bank powinien dokonywać bieżącej oceny jego wartości uwzględniając zaawansowanie procesu dochodzenia roszczeń i jego efekty. Bank nie powinien brać pod uwagę wartości zabezpieczenia hipotecznego, którego nie udało się zbyć w okresie 3 lat, od terminu wszczęcia egzekucji z nieruchomości przez bank. Bank powinien uzasadnić przyjęcie odmiennych założeń na podstawie oceny historycznych zmian zachodzących w zakresie kwot odzyskiwanych z zabezpieczeń (nie należy jednak uwzględniać przypadków nadmiernego zwlekania z podjęciem działań zmierzających do realizacji zabezpieczenia). 

- 14.15. W przypadku skorzystania przez kredytobiorcę z opcji „klucz za dług”, bank powinien w sposób szczególnie staranny ocenić wartość przejmowanej nieruchomości mieszkalnej. Dodatkowo, bank może w tym celu zlecić wykonanie oddzielnej wyceny nieruchomości niezależnemu rzeczoznawcy majątkowemu. 

Szczegółowe zasady w tym zakresie powinny zostać określone w umowie kredytowej. 

## **Rekomendacja 15** 

**Zarząd banku ustala poziomy wskaźnika LtV, w całym okresie spłaty ekspozycji. Poziomy wskaźnika LtV powinny być określone w zatwierdzonej przez radę nadzorczą banku strategii zarządzania ryzykiem. W Rekomendacji 1 określone są zasady dotyczące zatwierdzania i informowania o maksymalnych poziomach wskaźnika LtV przez bank spółdzielczy** . 

- 15.1. Wskaźnikiem wykorzystywanym do oceny adekwatności zabezpieczenia jest wskaźnik LtV. Bank powinien badać poziom tego wskaźnika przed podjęciem decyzji o udzieleniu kredytu, a także w trakcie trwania umowy monitorować jego poziom. 

- 15.2. Jednym z najistotniejszych czynników branych pod uwagę przy ustaleniu maksymalnego poziomu wskaźnika LtV powinien być przewidywany stopień odzysku zaangażowanych przez bank środków z danego typu zabezpieczenia. Bank powinien analizować czynniki wpływające na przewidywany poziom odzysku z zabezpieczenia tj.: 

   - a) jakość i obiektywność procesu oceny wartości zabezpieczenia na nieruchomości (poprzez porównanie oceny wartości zabezpieczenia w momencie udzielania kredytu i ceny zbycia zabezpieczenia lub ponownej oceny wartości zabezpieczenia w procesie dochodzenia należności) po wyeliminowaniu wpływu innych czynników takich jak zmienność rynku nieruchomości, czy wpływu przyjętego scenariusza zbycia zabezpieczenia, 

   - b) scenariusz zbycia zabezpieczenia (w porozumieniu z kredytobiorcą, w procedurze egzekucyjnej), 

   - c) efektywność procesu dochodzenia roszczeń, 

46 

- d) historyczna zmienność cen na rynku nieruchomości. 

Bank powinien gromadzić dane o wielkości odzyskiwanych środków z poszczególnych rodzajów zabezpieczeń i odpowiednio korygować stosowaną politykę kredytową (np. w zakresie maksymalnych poziomów wskaźnika LtV, zmian w zakresie zasad oceny wartości zabezpieczenia na nieruchomości, zmian procesu dochodzenia roszczeń). 

- 15.3. Dodatkowe kryteria, jakie bank powinien uwzględnić przy ustalaniu maksymalnych poziomów wskaźnika LtV, to m.in.: 

   - a) rodzaj nieruchomości stanowiącej zabezpieczenie, 

   - b) okres na jaki została zawarta umowa (im dłuższa umowa tym bardziej ostrożny poziom wskaźnika LtV), 

   - c) rodzaj oprocentowania, 

   - d) wartość dodatkowego obligatoryjnego zabezpieczenia ekspozycji kredytowej, o ile zostało przewidziane (np. ubezpieczenie spłat). 

Ustalone na podstawie powyższych kryteriów maksymalne poziomy wskaźnika LtV powinny zostać określone w wewnętrznych procedurach banku. Bank może pominąć wpływ wskazanych czynników w procesie wyznaczania poziomu wskaźnika LtV, gdy w stosowanych metodach oceny wartości zabezpieczenia uwzględnia wpływ wskazanych czynników na długoterminową wartość zabezpieczenia (np. w regulaminie oceny bankowo-hipotecznej wartości nieruchomości). 

- 15.4. Bank powinien wykazać zasadność przyjęcia maksymalnego poziomu wskaźnika LtV dla danego typu zabezpieczenia na podstawie własnych danych empirycznych lub obiektywnych analiz zewnętrznych. 

- 15.5. W przypadku ekspozycji kredytowych zabezpieczonych na nieruchomościach mieszkalnych, wartość wskaźnika LtV w momencie uruchomienia kredytu nie powinna przekraczać poziomu: 

   - a) 80% lub, 

   - b) 90% w przypadku, gdy dla części ekspozycji przekraczającej 80% LtV ustanowiono: 

      - odpowiednie ubezpieczenie, lub 

      - blokadę środków na rachunku bankowym lub zastaw na denominowanych w złotych dłużnych papierach wartościowych Skarbu Państwa lub NBP, lub 

      - przeniesienie określonej kwoty w złotych lub w innej walucie na własność banku, zgodnie z art. 102 ustawy – Prawo bankowe (przy czym w przypadku innej waluty niż waluta kredytu, bank powinien założyć jej deprecjację o co najmniej 50%), lub 

47 

      - przeniesienie środków klienta zgromadzonych na rachunku III filarowym, w ramach systemu emerytalnego tj. na Indywidualnym Koncie Emerytalnym (IKE) lub Indywidualnym Koncie Zabezpieczenia Emerytalnego (IKZE)[28][)] . 

- 15.5a.[29)] W przypadku ekspozycji kredytowych zabezpieczonych na nieruchomościach mieszkalnych będących gwarantowanymi kredytami mieszkaniowymi, wartość wskaźnika LtV w momencie uruchomienia kredytu nie powinna przekraczać poziomu wynikającego z zastosowania przepisów ustawy z dnia 1 października 2021 r. o rodzinnym kredycie mieszkaniowym ustalających zasady obejmowania gwarancją Banku Gospodarstwa Krajowego części gwarantowanego kredytu mieszkaniowego, tj. wartość wskaźnika LtV w momencie uruchomienia kredytu nie powinna przekraczać poziomu 100% pomniejszonego o wyrażony w procentach stosunek wkładu własnego do wartości nieruchomości. Jeżeli suma objętej gwarancją Banku Gospodarstwa Krajowego części gwarantowanego kredytu mieszkaniowego oraz wkładu własnego kredytobiorcy wynosi mniej niż 20% wartości nieruchomości, to dla części ekspozycji stanowiącej różnicę między 20% wartości nieruchomości a tą sumą powinno zostać ustanowione: 

   - a) odpowiednie ubezpieczenie, lub 

   - b) blokada środków na rachunku bankowym lub zastaw na denominowanych w złotych dłużnych papierach wartościowych Skarbu Państwa lub NBP, lub 

   - c) przeniesienie określonej kwoty w złotych lub w innej walucie na własność banku, zgodnie z art. 102 ustawy z dnia 29 sierpnia 1997 r. – Prawo bankowe (przy czym w przypadku innej waluty niż waluta kredytu, bank powinien założyć jej deprecjację o co najmniej 50%), lub 

   - d) przeniesienie środków klienta zgromadzonych na rachunku III filarowym, w ramach systemu emerytalnego, tj. na Indywidualnym Koncie Emerytalnym (IKE) lub Indywidualnym Koncie Zabezpieczenia Emerytalnego (IKZE). 

- 15.6. W przypadku kredytów z opcją „klucz za dług”, wartość wskaźnika LtV w momencie uruchomienia kredytu nie powinna przekraczać poziomu 70% wartości kredytowanej nieruchomości stanowiącej przedmiot zabezpieczenia. 

Dodatkowo, ustalając marżę związaną z udzieleniem kredytu z opcją „klucz za dług”, bank powinien ocenić ryzyko związane z tymi kredytami i odpowiednio je uwzględnić. 

- 15.7. Z zastrzeżeniem rekomendacji 15.8, w przypadku ekspozycji kredytowych zabezpieczonych na nieruchomościach komercyjnych wartość wskaźnika LtV w momencie udzielenia kredytu nie powinna przekraczać poziomu: 

a) 75% lub, 

- b) 80% w przypadku, gdy część ekspozycji przekraczająca 75% LtV ustanowiono: 

   - odpowiednie ubezpieczenie, lub 

28) Zgromadzone w ramach tych dobrowolnych planów emerytalnych środki podlegają przepisom ustawy z dnia 20 kwietnia 2004 r. o indywidualnych kontach emerytalnych oraz indywidualnych kontach zabezpieczenia emerytalnego (Dz. U. z 2022 r. poz. 1792). 

> 29) Dodany przez § 1 pkt 6 lit. b uchwały, o której mowa w odnośniku 1. 

48 

   - blokadę środków na rachunku bankowym lub zastaw na denominowanych w złotych dłużnych papierach wartościowych Skarbu Państwa lub NBP, lub 

   - przeniesienie określonej kwoty w złotych lub w innej walucie na własność banku, zgodnie z art. 102 ustawy – Prawo bankowe (przy czym w przypadku innej waluty niż waluta kredytu, bank powinien założyć jej deprecjację o co najmniej 50%), lub 

   - przeniesienie środków klienta zgromadzonych na rachunku III filarowym, w ramach systemu emerytalnego tj. na Indywidualnym Koncie Emerytalnym (IKE) lub Indywidualnym Koncie Zabezpieczenia Emerytalnego (IKZE)[30][)] . 

- 15.8. W odniesieniu do ekspozycji zabezpieczonych hipotecznie na pozostałych nieruchomościach komercyjnych i finansujących te nieruchomości, nie jest konieczne stosowanie postanowień Rekomendacji 15.7. 

## **Rekomendacja 16** 

## **Bank powinien śledzić zmiany zachodzące na rynku nieruchomości oraz monitorować wartość nieruchomości stanowiących zabezpieczenie posiadanych przez bank ekspozycji kredytowych.** 

- 16.1. W przypadku ekspozycji, dla których bieżący poziom wskaźnika LtV będzie niższy niż 80%, monitorowanie wartości nieruchomości powinno odbywać się nie rzadziej niż raz na trzy lata. W pozostałych przypadkach monitorowanie powinno się odbywać w cyklach rocznych. 

- 16.2. Bank istotnie zaangażowany w ekspozycje kredytowe zabezpieczone hipotecznie powinien monitorować sytuację na rynku nieruchomości oraz założenia i ramy prawnoekonomiczne, które zostały przyjęte do sporządzenia ocen wartości zabezpieczenia na nieruchomości oraz monitorowania wartości nieruchomości, a które mają istotny wpływ na ich wartość. 

## **Rekomendacja 17** 

## **Bank powinien posiadać odpowiednie pisemne procedury pozwalające na podjęcie szybkich środków zaradczych na wypadek nieprzewidzianych zdarzeń skutkujących spadkiem wartości nieruchomości, na której ustanowiono zabezpieczenie w odniesieniu do ekspozycji kredytowej banku.** 

- 17.1. W banku istotnie zaangażowanym w ekspozycje kredytowe zabezpieczone hipotecznie, procedury te powinny uwzględniać testy warunków skrajnych, pozwalające na symulację zachowania całego portfela i poszczególnych ekspozycji kredytowych, w sytuacji 

> 30) Zgromadzone w ramach tych dobrowolnych planów emerytalnych środki podlegają przepisom ustawy z dnia 20 kwietnia 2004 r. o indywidualnych kontach emerytalnych oraz indywidualnych kontach zabezpieczenia emerytalnego. 

49 

wystąpienia istotnych zmian wartości nieruchomości, na której ustanowiono zabezpieczenie, a przede wszystkim na ocenę efektów tych zmian. 

- 17.2. Bank powinien monitorować zmiany poziomu wskaźnika LtV w celu szybkiego reagowania na wzrost poziomu wskaźnika LtV, zwłaszcza przekroczenia określonych przez bank maksymalnych limitów. Bank powinien posiadać przygotowane na podstawie zatwierdzonej przez zarząd polityki banku, w formie pisemnej, procedury wewnętrzne określające sposób reakcji banku na negatywne zmiany wartości wskaźnika LtV. W szczególności procedury te powinny uwzględniać sytuacje, w których bieżący poziom wskaźnika LtV przekroczy 100%. 

- 17.3. Bank powinien zapewnić sobie, w umowie kredytowej, możliwość podjęcia stosownych kroków przewidzianych procedurami oraz wskazać, kiedy takie działania może podjąć. 

50 

## **IV. Monitorowanie i raportowanie w zakresie ryzyka ekspozycji kredytowych zabezpieczonych hipotecznie** 

## **Rekomendacja 18** 

**Bank powinien posiadać systemy monitorowania ekspozycji kredytowych zabezpieczonych hipotecznie, ze szczególnym uwzględnieniem procedur zapewniających spełnienie wymogów wynikających z przepisów prawa i regulacji wewnętrznych.** 

- 18.1. Procedury i regulaminy wewnętrzne powinny zapewniać: 

   - a) jakość i skuteczność wszystkich operacji administrowania ekspozycjami kredytowymi, 

   - b) dokładność oraz terminowość okresowego raportowania do zarządu, 

   - c) podział obowiązków, 

- d) zgodność procedur i regulaminów zatwierdzanych przez zarząd banku z regulacjami zewnętrznymi. 

- 18.2. Bank powinien określić komórki organizacyjne lub grupy osób odpowiedzialne za monitorowanie portfela takich ekspozycji. 

- 18.3. Jakość, szczegółowość oraz terminowość gromadzonych i prezentowanych wyników analiz powinna umożliwiać określenie przez zarząd banku, czy i w jakim stopniu realizowane są zasady polityki banku w zakresie ekspozycji kredytowych zabezpieczonych hipotecznie. 

- 18.4. Celem monitorowania portfela ekspozycji kredytowych zabezpieczonych hipotecznie jest: 

   - a) zapewnienie zgodności rozwoju portfela ze strategią banku, 

   - b) pomiar i ocena poziomu ryzyka w relacji do założonego apetytu na ryzyko, 

   - c) identyfikacja ekspozycji dotkniętych utratą wartości (zagrożonych) dla tworzenia odpisów (rezerw) na pokrycie strat, 

   - d) ocena adekwatności poziomu odpisów (rezerw), 

   - e) identyfikacja słabych stron w zakresie procesu zarządzania ryzykiem w celu podjęcia działań naprawczych. 

- 18.5. Monitorowanie portfela ekspozycji kredytowych zabezpieczonych hipotecznie powinno uwzględniać różnice wynikające z cech poszczególnych produktów kredytowych, ich docelowych grup klientów, przyjętych modeli akceptacji, sposobu dystrybucji, profilu ryzyka, stosowanych zabezpieczeń, monitoringu spłat i odzyskiwania należności. Monitorowanie w takim przypadku powinno być prowadzone na poziomie subportfeli o istotnym zróżnicowaniu cech produktu, celu finansowania, klienta, profilu ryzyka lub sposobu zabezpieczenia. 

51 

## **Rekomendacja 19** 

## **Bank powinien posiadać wewnętrzne systemy informacyjne, bazy danych oraz narzędzia analityczne, wspierające pomiar poziomu ryzyka związanego z ekspozycjami kredytowymi zabezpieczonymi hipotecznie.** 

- 19.1. Podstawowym celem zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie jest utrzymanie poziomu ryzyka związanego z tym portfelem ekspozycji w ramach i w zakresie przewidzianym w zasadach polityki przyjętej przez bank. 

- 19.2. Posiadane przez bank systemy powinny umożliwiać uzyskiwanie niezbędnych informacji dotyczących struktury portfela ekspozycji kredytowych zabezpieczonych hipotecznie w różnych przekrojach, jego jakości i zmian w nim zachodzących. 

- 19.3. Bank powinien posiadać techniki służące do mierzenia ryzyka poszczególnych ekspozycji kredytowych zabezpieczonych hipotecznie oraz całego portfela tych ekspozycji. Pomiar ryzyka powinien brać pod uwagę w szczególności: 

   - a) specyfikę ekspozycji kredytowych zabezpieczonych hipotecznie, 

   - b) profil ekspozycji na ryzyko uwzględniający cel kredytowania, „wiek” ekspozycji, charakterystykę kredytobiorców, informacje o zachowaniu kredytobiorców (z baz danych oraz, w miarę możliwości, z baz danych gospodarczych, np. historia spłat, zmiany w poziomie zadłużenia), a także zmiany zachodzące na rynku nieruchomości, 

   - c) wielkość łącznej ekspozycji banku wobec klienta, 

   - d) istnienie możliwości stosowania dodatkowych zabezpieczeń, 

   - e) potencjalną wielkość straty kredytowej[31][)] . 

- 19.4. Analiza danych określających poziom ryzyka powinna być dokonywana co najmniej raz na kwartał – z uwzględnieniem co najmniej wskaźników określonych w załącznikach II oraz III (formularze B i C) do Zalecenia Europejskiej Rady Ryzyka Systemowego z dnia 31 października 2016 r. w sprawie uzupełniania luk w danych dotyczących sektora nieruchomości (ERRS/2016/14). Techniki pomiaru powinny być dostosowane do poziomu złożoności i wielkości ryzyka zawartego w portfelu oraz możliwości technicznych banku. Bank powinien zapewnić w umowach zawieranych z klientami możliwość uzyskania od klienta danych pozwalających na ustalenie bieżącego poziomu wskaźnika DStI. 

- 19.5. Bank powinien identyfikować klientów, których kredyty charakteryzują się wysokim wskaźnikiem DStI (przekraczającym 30% w przypadku klientów o dochodach nieprzekraczających przeciętnego poziomu wynagrodzeń w gospodarce lub danym regionie zamieszkania, lub 40% dla pozostałych klientów) i niskim buforze dochodowym oraz co najmniej raz na rok analizować ich sytuację i odporność na wzrost stóp procentowych, szczególnie w środowisku niskich stóp procentowych. 

31) Pomiar wielkości straty kredytowej nie musi być związany z koniecznością stosowania przez bank metod zaawansowanych. 

52 

- 19.6. Bank powinien aktywnie podejmować działania, w szczególności przedkładając propozycje modyfikacji zawartych umów kredytowych, mające na celu ograniczenie ryzyka związanego z ewentualnymi problemami klientów ze spłatą kredytów w przypadku wzrostu stóp procentowych. Banki powinny działać w tym zakresie z uwzględnieniem i poszanowaniem interesów klientów oraz podejmować czynności mające na celu faktyczną poprawę sytuacji klientów. 

- 19.7. W przypadku kredytów zabezpieczonych hipotecznie oprocentowanych okresowo stałą stopą procentową bank powinien nie później niż dwa miesiące przed terminem zmiany formuły oprocentowania, przedstawić kredytobiorcy, na trwałym nośniku lub w postaci elektronicznej, informacje o oprocentowaniu kredytu według wszystkich oferowanych przez bank formuł oprocentowania. 

   - Informacje przekazywane przez bank powinny być jasne, precyzyjne i kompletne, tak aby pozwalały kredytobiorcy na dokonanie świadomego wyboru formuły oprocentowania kredytu. 

   - Przedstawiając kredytobiorcy informacje w tym zakresie, bank powinien uwzględniać rekomendacje dotyczące relacji z klientami. 

## **Rekomendacja 20** 

**Bank powinien posiadać zatwierdzone przez zarząd wewnętrzne limity ograniczające ryzyko kredytowe odnoszące się do całego portfela oraz poszczególnych rodzajów ekspozycji kredytowych zabezpieczonych hipotecznie. Limity te powinny odzwierciedlać zróżnicowanie ekspozycji kredytowych i przyjętych zabezpieczeń, strukturę i stabilność źródeł finansowania oraz poziom apetytu na ryzyko banku.** 

- 20.1. Wprowadzone procedury powinny zapewniać odpowiednią dywersyfikację portfela i zgodność z ogólną strategią banku. Dlatego istotnym elementem procesu zarządzania ryzykiem związanym z ekspozycjami kredytowymi zabezpieczonymi hipotecznie, jest ustalenie przez bank limitów zaangażowania banku ograniczających nadmierną ekspozycję na ryzyko. Limity te powinny być zgodne z wymogami Komisji Nadzoru Finansowego w zakresie zasad funkcjonowania systemu zarządzania ryzykiem w bankach. Limity te powinny ponadto odzwierciedlać wielkość apetytu na ryzyko banku. 

- 20.2. Bank powinien posiadać co najmniej limity ograniczające ryzyko ekspozycji kredytowych zabezpieczonych hipotecznie oraz portfeli poszczególnych rodzajów tych ekspozycji, w tym m.in. ekspozycji wobec podmiotów gospodarczych zabezpieczonych hipotecznie na nieruchomościach mieszkalnych lub komercyjnych. Limity powinny uwzględniać zróżnicowanie ekspozycji kredytowych i zabezpieczeń. 

- 20.3. Aby ustalone limity spełniały swoje funkcje bank powinien przed ich wprowadzeniem przeprowadzić i udokumentować efektywny pomiar potencjalnego poziomu ekspozycji na ryzyko. Limity, ustalane zgodnie z obowiązującymi w tym zakresie przepisami, powinny gwarantować odpowiednią dywersyfikację portfela ekspozycji kredytowych zabezpieczonych hipotecznie. Przyjęte limity powinny odnosić się w szczególności do: 

a) grup (segmentów) klientów, w tym sektorów gospodarki, 

53 

b) celu finansowania, 

c)[32][)] rodzajów produktów (w szczególności do kredytów zabezpieczonych hipotecznie oprocentowanych stałą stopą procentową, okresowo stałą stopą procentową, zmienną stopą procentową oraz kredytów z opcją „klucz za dług”, a także gwarantowanych kredytów mieszkaniowych), z uwzględnieniem stosowanego przez bank modelu szacującego poziom wcześniejszych spłat, 

- d) zabezpieczeń, w tym maksymalnego poziomu wskaźnika LtV, 

- e) długości okresu umowy, 

- f) waluty ekspozycji kredytowej, 

- g) ekspozycji geograficznej (klientów lub zabezpieczeń z danego obszaru). 

Wymienione kryteria tworzenia limitów są kryteriami możliwymi do zastosowania w zależności od skali i struktury zaangażowania banku w ekspozycje kredytowe zabezpieczone hipotecznie. W merytorycznie uzasadnionych przypadkach dopuszczalne jest stosowanie przez bank własnych rozwiązań w tym zakresie. 

- 20.4. Przy ustalaniu wielkości limitów bank istotnie zaangażowany powinien uwzględniać testy warunków skrajnych badające wrażliwość dłużników i banku na zmiany otoczenia gospodarczego. W szczególności bank powinien uwzględniać: 

   - a) cykle koniunkturalne, 

   - b) zmiany w poziomie dochodów gospodarstw domowych, 

   - c) zmiany w poziomie bezrobocia, 

   - d) zmiany płynności rynków finansowych, 

   - e) wahania stóp procentowych, 

   - f) zmiany kursów walutowych, 

   - g) zmiany na rynku nieruchomości. 

Bank istotnie zaangażowany w ekspozycje kredytowe zabezpieczone hipotecznie powinien przeprowadzać testy warunków skrajnych przynajmniej raz w roku. Częstsze dokonywanie testów zalecane jest w razie zaistnienia istotnych zmian warunków rynkowych. 

- 20.5. Bank istotnie zaangażowany w ekspozycje kredytowe zabezpieczone hipotecznie powinien określić poziom apetytu na ryzyko także poprzez określenie dla portfeli i subportfeli takich ekspozycji (w tym, m.in. uwzględniając podział na ekspozycje kredytowe zabezpieczone hipotecznie oprocentowane stałą stopą procentową, okresowo stałą stopą procentową, zmienną stopą procentową oraz kredytów z opcją „klucz za dług”, 

> 32) W brzmieniu ustalonym przez § 1 pkt 7 lit. a tiret pierwsze uchwały, o której mowa w odnośniku 1. 

54 

a także gwarantowanych kredytów mieszkaniowych) dodatkowych parametrów, które w szczególności powinny odnosić się do:[ 33)] 

- a) średniego prawdopodobieństwa niewykonania zobowiązania przez kredytobiorców[34)] , 

b) średniego poziomu odzysku ze stosowanych zabezpieczeń[35)] , 

c) potencjalnego maksymalnego poziomu nieodzyskanych kredytów, 

ca)[36)] potencjalnego wpływu nadpłat kredytu, 

d) poziomu akceptowalnych klas (ratingów) wyznaczonych dla klienta. 

- 20.6. Informacja o przekroczeniu limitów każdorazowo powinna być przedstawiona zarządowi banku i zawierać przyczynę przekroczenia limitów. 

- 20.7. Wysoki poziom wykorzystania przyjętych limitów powinien być przesłanką do weryfikacji polityki zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie w celu przeciwdziałania ich przekroczeniu. 

## **Rekomendacja 21** 

## **Bank powinien szczegółowo analizować i dostosowywać strukturę terminową źródeł finansowania i strukturę terminową aktywów.** 

- 21.1. Bank powinien poddawać szczególnej analizie narażenie banku na ryzyko utraty płynności związane z portfelem ekspozycji kredytowych zabezpieczonych hipotecznie. 

- 21.2. Co najmniej raz w roku, bank powinien przeprowadzać pogłębioną analizę źródeł finansowania ekspozycji kredytowych zabezpieczonych hipotecznie. 

- 21.3. W zależności od struktury portfela ekspozycji kredytowych zabezpieczonych hipotecznie analiza powinna zawierać przynajmniej następujące elementy: 

   - a) strukturę terminową ekspozycji kredytowych zabezpieczonych hipotecznie, w tym analizę ich jakości, 

b) wskazanie wiarygodnych źródeł refinansowania długoterminowych ekspozycji kredytowych zabezpieczonych hipotecznie adekwatnie do waluty ekspozycji i rodzaju oprocentowania, 

ba)[37)] wyniki analiz poziomu nadpłat wynikające ze stosowanego przez bank modelu szacującego poziom wcześniejszych spłat (ang.: _prepayment model_ ), 

c) symulację dotyczącą wpływu na sytuację banku w zakresie płynności i rentowności 

> 33) Wprowadzenie do wyliczenia w brzmieniu ustalonym przez § 1 pkt 7 lit. a tiret drugie podwójny tiret pierwsze uchwały, o której mowa w odnośniku 1. 

> 34) Pojęcie to nie jest tożsame z Probability of Default (PD) i nie wymaga stosowania przez banki metod zaawansowanych. 

> 35) Określenie poziomu odzysku nie wymaga stosowania przez bank metod zaawansowanych. 

> 36) Dodana przez § 1 pkt 7 lit. a tiret drugie podwójny tiret drugie uchwały, o której mowa w odnośniku 1. 

> 37) Dodana przez § 1 pkt 7 lit. b uchwały, o której mowa w odnośniku 1. 

55 

możliwych zmian warunków rynkowych, np. zmian na rynku finansowania hurtowego, rynku instrumentów zabezpieczających przed ryzykiem i rynku walutowym, 

d) skutki negatywnych zmian w zakresie płynności rynków finansowych (testy warunków skrajnych), w tym ryzyko odnowienia niedopasowanych terminowo źródeł finansowania oraz wpływ na koszt pozyskiwanych funduszy. 

- 21.4. Bank powinien podejmować działania zmierzające do dywersyfikacji źródeł finansowania działalności w celu ograniczania ryzyka płynności, szczególnie długoterminowej (np. poprzez sekurytyzację, emisję listów zastawnych, emisję innych długoterminowych papierów wartościowych, w tym zabezpieczonych hipotecznie). 

- 21.5. Bank powinien opracować plan pozyskiwania długoterminowych źródeł finansowania, w tym działań awaryjnych oraz monitorować jego realizację (nie rzadziej niż w okresach analizy). 

## **Rekomendacja 22** 

**Bank powinien na bieżąco kontrolować, czy wszystkie warunki umowy są wypełniane przez klienta oraz czy środki finansowe wypłacane przez bank wykorzystywane są zgodnie z umową.** 

- 22.1. Bank powinien określić w swoich procedurach zakres i częstotliwość kontroli oraz jednostki odpowiedzialne za jej przeprowadzenie. 

- 22.2. Zakres kontroli powinien obejmować adekwatnie do finansowanej transakcji przynajmniej: 

   - a) ustanowienie zabezpieczeń, 

   - b) wniesienie wkładu własnego, 

   - c) spełnienie warunków uruchomienia środków (transz), 

d) spełnienie dodatkowych warunków w trakcie umowy (covenants), 

   - e) realizację inwestycji zgodnie z kosztorysem i harmonogramem, 

   - f) uzyskiwanie niezbędnych zgód przez kredytobiorcę. 

- 22.3. Kontrola powinna się odbywać na podstawie dokumentów przedkładanych przez kredytobiorcę lub informacji i danych gromadzonych przez bank. 

- 22.4. Częstotliwość kontroli powinna być adekwatna do kontrolowanego zakresu oraz terminów przyjętych w umowie kredytu (wypłacanego w transzach). W przypadku finansowania inwestycji, kontrola powinna być prowadzona w szczególności: 

   - a) w zakresie wniesienia wkładu własnego, 

   - b) przed wypłatą drugiej i kolejnych transz kredytu, 

   - c) po zakończeniu inwestycji. 

- 22.5. Dodatkowe kontrole powinny zostać przeprowadzone, jeśli bank znajdzie się 

56 

w posiadaniu informacji wskazujących na negatywną zmianę ekspozycji na ryzyko, wynikającej np. z pogorszenia się sytuacji finansowej kredytobiorcy lub zalegania w spłacie kredytu. Wszelkie tego typu informacje powinny zostać bezzwłocznie zgłoszone i przekazane odpowiedzialnym w tym zakresie komórkom i pracownikom banku. 

- 22.6. W przypadku, gdy kontrola realizowana jest na rzecz banku przez podmioty zewnętrzne, bank powinien określić zasady i procedury jej przeprowadzania oraz weryfikacji jakości. Bank powinien zapewnić, aby weryfikacja jakości kontroli była dokonywana przez pracowników banku niezależnych od obszaru sprzedaży. 

- 22.7.[38)] Bank powinien ustanowić taką strukturę finansowania inwestycji, aby zapewnić podział ryzyka pomiędzy kredytobiorcę i bank, głównie poprzez odpowiednie zaangażowanie środków własnych kredytobiorcy (wkład własny), biorąc pod uwagę w określonych przypadkach możliwość udzielenia gwarantowanych kredytów mieszkaniowych. 

- 22.8.[39)] Z zastrzeżeniem przepisów prawa (w szczególności dotyczących programów rządowych i innych o podobnym charakterze, w tym programu uruchamiającego gwarantowany kredyt mieszkaniowy) wprowadzających odrębne zasady w tym zakresie oraz z wyjątkiem przypadków uzasadnionych szczególnym charakterem transakcji (np. finansowanie wkładu własnego ze zbycia posiadanej i wykorzystywanej nieruchomości mieszkalnej lub zaangażowanie środków finansowych kredytobiorcy w lokatę bankową o terminie zapadalności krótszym niż okres kredytowania) bank powinien uruchamiać środki z kredytu po wniesieniu minimalnego wymaganego wkładu własnego przez kredytobiorcę. 

- 22.9. Bank powinien zapewnić, aby kontrola wniesienia wkładu własnego, realizacji inwestycji, uzyskiwania zgód była wykonywana z zachowaniem niezależności i obiektywizmu przez osoby dysponujące niezbędnymi kwalifikacjami w zakresie objętym kontrolą. Kontrola taka powinna odbywać się poprzez weryfikację ze stanem faktycznym przedstawianych przez kredytobiorcę dokumentów lub bezpośrednią ocenę stanu faktycznego. 

- 22.10. W przypadku ekspozycji kredytowej zabezpieczonej hipotecznie uruchamianej w transzach wypłata kolejnej transzy, uwzględniając specyfikę (charakter) inwestycji, powinna następować po rozliczeniu wykorzystania transzy poprzedniej, tj. po dokonaniu weryfikacji czy poprzednia transza została wykorzystana w sposób określony w umowie, zgodnie z jej celem i przeznaczeniem. 

- 22.11. Z wyłączeniem detalicznych ekspozycji kredytowych zabezpieczonych hipotecznie, struktura oraz sposób uruchamiania kolejnych transz finansowanej inwestycji powinny zapewnić bankowi możliwość kontroli: 

   - a) jakości i stabilności przyjętego źródła spłaty kredytu, 

   - b) zmiany parametrów zidentyfikowanych jako wrażliwe z punktu widzenia poziomu ryzyka ekspozycji, 

38) W brzmieniu ustalonym przez § 1 pkt 7 lit. c uchwały, o której mowa w odnośniku 1. 

57 

- c) wykorzystania uruchamianych środków, 

- d) zaawansowania technicznego, kosztowego i terminowego finansowanej inwestycji, 

- e) wniesienia wkładu własnego przez kredytobiorcę, 

- f) wypełnienia przez kredytobiorcę innych warunków zawartych w umowie kredytowej 

oraz ograniczyć negatywny wpływ innych rodzajów ryzyka niezwiązanych z finansowaną inwestycją, ale ponoszonych przez kredytobiorcę. 

- 22.12. Warunki spłaty ekspozycji kredytowej powinny uwzględniać charakterystykę finansowanej transakcji/inwestycji, ale jednocześnie umożliwiać pośrednią kontrolę poprzez systematyczne monitorowanie spłat. W szczególności bank, uwzględniając specyfikę (charakter) transakcji, powinien unikać: 

   - a) okresów karencji w spłacie odsetek, 

   - b) okresów karencji w spłacie kapitału, m.in. po okresie realizacji inwestycji/transakcji, jeśli źródłem spłaty są przychody z finansowanej inwestycji/transakcji lub źródło spłaty zależy od wartości finansowanej nieruchomości, 

   - c) nadmiernie wydłużonych terminów spłaty ekspozycji wynikających z ich niskiej rentowności (i w konsekwencji wysokiej wrażliwości na ryzyko), 

   - d) nadmiernej koncentracji ekspozycji o balonowym harmonogramie spłat w portfelu kredytowym. 

## **Rekomendacja 23** 

**Bank powinien zapewnić skuteczny system raportowania realizacji polityki zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie oraz poziomu ryzyka z tytułu tych ekspozycji, dostarczający informacji umożliwiających podjęcie działań zapewniających utrzymanie przyjętego poziomu apetytu na ryzyko.** 

- 23.1. Podstawowym zadaniem systemu raportowania jest przedstawienie niezbędnej informacji pozwalającej na ocenę ryzyka ekspozycji kredytowych zabezpieczonych hipotecznie przez zarząd banku i podejmowanie decyzji. 

- 23.2. Proces raportowania służy określeniu skuteczności zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie, identyfikacji źródeł i czynników ryzyka, pomiarowi kosztów ryzyka, ograniczaniu poziomu ryzyka, przestrzeganiu przyjętych limitów oraz umożliwieniu podjęcia odpowiednich działań naprawczych i profilaktycznych. 

- 23.3. Bank określa w polityce zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie zakres i częstotliwość raportowania, odbiorców raportów oraz komórki odpowiedzialne za ich sporządzanie. 

- 23.4. W przypadku detalicznych ekspozycji kredytowych zabezpieczonych hipotecznie, raporty odnośnie tych ekspozycji mogą być wyodrębnioną częścią systemu raportowania detalicznych ekspozycji kredytowych. 

58 

- 23.5. Bank określając zakres i częstotliwość raportowania uwzględnia stopień zaangażowania banku w ekspozycje kredytowe zabezpieczone hipotecznie, rodzaj produktów, poziom apetytu na ryzyko, profil ryzyka, przyjęty poziom zabezpieczenia ekspozycji kredytowych oraz zmiany w otoczeniu banku. 

- 23.6. Dla ekspozycji kredytowych zabezpieczonych hipotecznie na nieruchomościach mieszkalnych, raportowanie w zakresie bieżącego poziomu wskaźnika LtV, powinno odbywać się nie rzadziej niż raz na kwartał. 

- 23.7. W banku istotnie zaangażowanym w ekspozycje kredytowe zabezpieczone hipotecznie na nieruchomościach komercyjnych raportowanie powinno odbywać się nie rzadziej niż raz na kwartał, a w przypadku przekroczenia przyjętych limitów lub, gdy przeciętny bieżący poziom wskaźnika LtV jest wyższy niż 80%, nie rzadziej niż raz na miesiąc. 

W pozostałych bankach raportowanie powinno odbywać się nie rzadziej niż raz na rok. 

- 23.8. Zakres raportowania powinien w szczególności obejmować: 

a) jakość ekspozycji kredytowych (np. wielkość opóźnień oraz poziom migracji między klasami opóźnień, w tym według grup klientów, czasu udzielenia zaangażowania ( _ang.: vintage_ )), 

b) poziom i adekwatność odpisów (rezerw), 

c) wykorzystanie i przestrzeganie przyjętych limitów, 

d) przebieg procesu akceptacji, skalę odstępstw (przełamań), 

e) wyniki działania i skuteczność narzędzi wspierających ocenę zdolności kredytowej, 

f) wyniki procesu monitorowania ekspozycji i dochodzenia roszczeń (w tym określenie zaawansowania procesów), 

fa)[39)] informacje na temat poziomu nadpłat kredytów, w tym wynikające ze stosowanego przez bank modelu szacującego poziom wcześniejszych spłat (ang.: _prepayment model_ ), 

g) kwoty nieodzyskane (straty kredytowe), 

h) zaawansowanie procesu ustanawiania zabezpieczeń, 

i) poziom pokrycia ekspozycji zabezpieczeniami (w szczególności hipotecznymi), 

j) wartości odzysku z zabezpieczeń (w tym z poszczególnych scenariuszy dochodzenia należności, np. egzekucji komorniczej, uzgodnionej sprzedaży nieruchomości przez kredytobiorcę). 

Raportowanie powinno uwzględniać w szczególności podział produktów na kredyty hipoteczne oprocentowane stałą stopą procentową, okresowo stałą stopą procentową, 

> 39) Dodana przez § 1 pkt 7 lit. d tiret pierwsze uchwały, o której mowa w odnośniku 1. 

59 

zmienną stopą procentową oraz kredyty z opcją „klucz za dług”, a także gwarantowane kredyty mieszkaniowe.[40)] 

- 23.9.  W sytuacji istotnych zmian w otoczeniu banku oraz w samym banku wpływających na przebieg procesu kredytowego lub profil ryzyka ponoszonego przez bank, częstotliwość raportowania powinna ulec zwiększeniu, a jego zakres stosownym modyfikacjom. 

40) W brzmieniu ustalonym przez § 1 pkt 7 lit. d tiret drugie uchwały, o której mowa w odnośniku 1. 

60 

## **V. System kontroli wewnętrznej** 

## **Rekomendacja 24** 

**Bank powinien zapewnić, aby system kontroli wewnętrznej, funkcjonujący zgodnie z postanowieniami Rekomendacji H dotyczącej systemu kontroli wewnętrznej w bankach, obejmował działalność banku w zakresie ekspozycji kredytowych zabezpieczonych hipotecznie.** 

- 24.1. Regulacje wewnętrzne określające zasady i sposoby kontrolowania powinny być sporządzone w formie pisemnej i przyjęte przez zarząd banku. Wprowadzając lub zmieniając regulacje dotyczące zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie bank powinien uwzględnić: 

   - a)  jakość i skuteczność wszystkich operacji związanych z procesem oceny zdolności kredytowej, 

   - b)  jakość i skuteczność zarządzania ryzykiem portfela ekspozycji kredytowych zabezpieczonych hipotecznie, 

   - c)  dokładność oraz terminowość okresowego raportowania do zarządu, 

   - d)  podział obowiązków w procesie kredytowym, 

   - e) zgodność procedur i regulaminów z zewnętrznymi regulacjami. 

- 24.2. Bank powinien zidentyfikować podstawowe obszary podlegające systemowi kontroli wewnętrznej. Wśród najistotniejszych należy wskazać: 

   - a) przestrzeganie polityki zarządzania ryzykiem ekspozycji kredytowych zabezpieczonych hipotecznie, 

   - b) skuteczność limitów ograniczających ryzyko ekspozycji kredytowych zabezpieczonych hipotecznie, 

   - c) wymogi dokumentowe w zakresie badania zdolności kredytowej, 

   - d) korzystanie z wewnętrznych i zewnętrznych źródeł informacji, np. baz danych, 

   - e) minimalne wymogi w zakresie przyjętych formuł oceny zdolności kredytowej, dochodów i wydatków klientów oraz przyjętych w tym zakresie limitów, 

   - f) skuteczność systemu uprawnień do akceptacji ryzyka, 

   - g) skuteczność ograniczania strat poprzez zabezpieczanie ekspozycji kredytowych zabezpieczonych hipotecznie, 

   - h) jakość administracji ekspozycjami kredytowymi, 

   - i) skuteczność procesów monitorowania ekspozycji kredytowych i dochodzenia roszczeń, 

   - j) przeprowadzanie testów warunków skrajnych, 

   - k) statystyczne narzędzia wspierające ocenę zdolności kredytowej. 

61 

- 24.3. Czynności wykonywane w ramach systemu kontroli wewnętrznej w obszarze działalności banku w zakresie ekspozycji kredytowych zabezpieczonych hipotecznie powinny być dokonywane regularnie, w zależności od zidentyfikowanego profilu i poziomu ryzyka. 

- 24.4. System kontroli wewnętrznej powinien również zapewnić, aby informacja o wyjątkach od przyjętych zasad, obowiązujących procedur, regulacji i limitów lub ich naruszeniu była w odpowiednim czasie przekazywana zarządowi banku. 

62 

## **VI. Relacje z klientami** 

## **Rekomendacja 25** 

**Bank powinien posiadać sporządzone w formie pisemnej procedury wewnętrzne określające sposób i zakres informowania każdego klienta ubiegającego się o kredyt zabezpieczony hipotecznie oraz uwzględniające wymogi w tym zakresie wynikające z przepisów ustawy o kredycie hipotecznym oraz o nadzorze nad pośrednikami kredytu hipotecznego i agentami. Bank powinien dołożyć wszelkich starań, aby przekazywane klientom informacje były zrozumiałe, jednoznaczne i czytelne. Dotyczy to informacji przedstawianych zarówno przed, w trakcie, jak i po podpisaniu umowy. Bank powinien uwzględniać poziom wiedzy klienta.** 

- 25.1. Przed zawarciem umowy, klient powinien otrzymać w sposób przewidziany ustawą, a o ile ustawa tego nie precyzuje, zgodnie z niniejszą rekomendacją, pisemnie informacje istotne dla oceny ryzyka i kosztów związanych z zawarciem umowy o kredyt zabezpieczony hipotecznie oprocentowany zmienną stopą procentową, stałą stopą procentową lub okresowo stałą stopą procentową z uwzględnieniem specyfiki konkretnego produktu, w tym w szczególności informacje na temat: 

a) charakterystyki czynników ryzyka związanych z oferowanymi rodzajami kredytu, 

b) wysokości raty kredytu w funkcji okresu kredytowania dla oferowanych rodzajów kredytu, 

c) tempa spłacania kapitału w funkcji okresu kredytowania dla oferowanych rodzajów kredytu, 

d) całkowitego kosztu kredytu (z uwzględnieniem ubezpieczeń zawartych w związku z tym kredytem) w funkcji okresu kredytowania dla oferowanych rodzajów kredytu, 

e) całkowitej kwoty do zapłaty przez konsumenta dla oferowanych rodzajów kredytu, 

f) ryzyka zmiany oprocentowania dla oferowanych rodzajów kredytu, 

g)[41)] konsekwencji spadku wartości nieruchomości, na której ustanawiane jest zabezpieczenie, dla klienta (informacje te powinny bazować na symulacji zmiany wartości tej nieruchomości i odniesieniu tej zmienionej wartości do wysokości kredytu, uwzględniając co najmniej wyższy z dwóch spadków – (i) najwyższy spadek cen nieruchomości odnotowany w okresie poprzedzającym datę sporządzenia symulacji równym planowanemu okresowi kredytowania lub (ii) spadek cen nieruchomości odnotowany w okresie I kwartał 2008 r. do IV kwartał 2012 r.; bank może w tym celu korzystać z baz danych o rynku nieruchomości, a w przypadku gdy bazy te nie zawierają danych dla wystarczająco długiego okresu, bank powinien użyć danych dla najdłuższego 

> 41) Dodana przez § 1 pkt 8 lit. a tiret pierwsze uchwały, o której mowa w odnośniku 1. 

63 

dostępnego okresu, bank powinien dołożyć należytej staranności, by użyć danych o nieruchomościach podobnych do tej, na której ustanowione ma być zabezpieczenie), 

h)[42)] limitu dopłat oraz ryzyka wzrostu oprocentowania po ustaniu okresu dopłat – w przypadku kredytu udzielanego w ramach programu rządowego zakładającego dopłaty do oprocentowania kredytu. 

- 25.2. Rekomenduje się, aby bank oferujący kredyty z opcją „klucz za dług” – w zakresie swojej oferty kredytów oprocentowanych zmienną stopą procentową, kredytów oprocentowanych stałą stopą procentową oraz kredytów oprocentowanych okresowo stałą stopą procentową – dla każdego z oferowanych rodzajów kredytów, przedstawiał klientom ofertę zarówno kredytów z opcją „klucz za dług”, jak też bez takiej opcji. 

- 25.3. Zakres przekazywanych informacji powinien zapewnić klientowi uzyskanie niezbędnej wiedzy na temat specyfiki danego produktu, w szczególności na temat charakterystyki czynników ryzyka z nim związanych, w kontekście zróżnicowania oferty w zakresie kredytów zabezpieczonych hipotecznie: 

a) oprocentowanych zmienną stopą procentową, stałą stopą procentową i okresowo stałą stopą procentową, 

b) z opcją „klucz za dług” oraz bez takiej opcji, 

c)[43)] będących gwarantowanym kredytem mieszkaniowym. 

- 25.4. Przekazywane klientowi informacje dotyczące kredytów zabezpieczonych hipotecznie powinny w sposób jednoznaczny i przejrzysty odnosić się do rodzaju oferowanych produktów i wskazywać w szczególności czynniki wpływające na koszt obsługi kredytu, jak również jasno opisywać zmiany sposobu oprocentowania kredytu (przejście z oprocentowania stopą stałą na oprocentowanie stopą zmienną lub zamiana na nową stałą stopę), jeśli umowa to przewiduje. 

W przypadku banku oferującego kredyty z opcją „klucz za dług”, bank powinien poinformować klienta, wraz z uzasadnieniem, o potencjalnie wyższym koszcie obsługi kredytu z opcją „klucz za dług” ze wskazaniem kosztów i czynników ryzyka związanych z tego rodzaju kredytami. Bank powinien również poinformować klienta o kosztach podatkowych z tytułu umorzenia części zobowiązania klienta – w przypadku, gdy klient skorzysta z opcji „klucz za dług” i kwota uzyskana ze sprzedaży kredytowanej nieruchomości będzie mniejsza niż wysokość zadłużenia w momencie przeniesienia przez kredytobiorcę na bank własności do kredytowanej nieruchomości. 

- 25.5. Bank powinien rekomendować klientom detalicznym okres spłaty nie dłuższy niż 25 lat, a w przypadku klientów zamierzających zaciągnąć kredyt na okres powyżej 25 lat bank, jako profesjonalny uczestnik rynku, powinien przedstawić klientowi w formie pisemnej: 

> 42) Dodana przez § 1 pkt 8 lit. a tiret drugie uchwały, o której mowa w odnośniku 1. 

> 43) Dodana przez § 1 pkt 8 lit. b uchwały, o której mowa w odnośniku 1. 

64 

   - a) różnicę pomiędzy wysokością raty spłaty wynikającą z wydłużenia okresu kredytowania powyżej 25 lat, a wysokością raty spłaty wynikającą z 25-letniego okresu kredytowania oraz 

   - b) różnicę w całkowitym koszcie kredytu (odsetkowym i innym) pomiędzy kredytem zaciąganym na planowany okres spłaty (przekraczający 25 lat), a kredytem udzielonym na okres 25 lat. 

- 25.6. W przypadku klientów o dochodach nieprzekraczających przeciętnego poziomu wynagrodzeń w gospodarce lub danym regionie zamieszkania, dla których wstępna analiza wniosków kredytowych wskazuje na przekroczenie przez wskaźnik DStI 40% lub w przypadku przekroczenia przez wskaźnik DStI 50% dla pozostałych klientów, bank jako profesjonalny uczestnik rynku, powinien zwrócić klientom uwagę na bardzo długi okres spłaty zobowiązania, a w związku z tym konieczność zachowania odpowiedniego bufora dochodowego na wypadek pogorszenia ich sytuacji dochodowej lub realizacji większych wydatków. 

- 25.7. Bank powinien w sposób przewidziany ustawą, a o ile ustawa tego nie precyzuje, zgodnie z niniejszą rekomendacją, regularnie dostarczać swoim klientom wszelkich informacji dotyczących warunków umowy kredytowej oraz ich praw i obowiązków wynikających z tej umowy. W szczególności, bank na trwałym nośniku lub w postaci elektronicznej, powinien informować klienta o wszelkich zmianach, które wpływają bezpośrednio na warunki umowy kredytowej, szczególnie na poziom obciążeń z tytułu spłaty kredytu (np. zmianach stóp procentowych, zasad ustalania spreadu walutowego). 

- 25.8. Bank powinien w sposób przewidziany ustawą, a o ile ustawa tego nie precyzuje, zgodnie z niniejszą rekomendacją, przedstawiać klientom informacje o całkowitym koszcie kredytu oraz rzeczywistej rocznej stopie procentowej uwzględniające koszty znane w momencie zawarcia umowy. W tym celu bank powinien zamieszczać w ogłoszeniach i reklamach dotyczących kredytu zawierających warunki udzielania kredytu, rzeczywistą roczną stopę procentową, wyliczoną od całkowitego kosztu kredytu. 

- 25.9. Bank powinien posiadać sporządzone w formie pisemnej, procedury wewnętrzne określające sposób i zakres informowania każdego klienta zaciągającego kredyt o związanym z tym ryzyku, jak i jego konsekwencjach. Wszystkie pytania i wątpliwości w tym zakresie powinny zostać wyjaśnione klientowi przez odpowiednio wyszkolonego pracownika, posiadającego niezbędną wiedzę na temat zagrożeń związanych z ryzykiem stopy procentowej ekspozycji kredytowych zabezpieczonych hipotecznie. Klient zaciągający kredyt zabezpieczony hipotecznie oprocentowany zmienną stopą procentową lub okresowo stałą stopą procentową powinien podpisać oświadczenie, iż został poinformowany przez bank o ponoszeniu ryzyka stopy procentowej oraz, że jest świadomy jego ponoszenia. Powyższe zasady odnoszą się również do innych niż kredyty zabezpieczone hipotecznie ekspozycji kredytowych. 

- 25.10. W celu zapewnienia porównywalności stosowanych przez banki polityk dotyczących wyznaczania spreadów walutowych, bank powinien zapewnić klientom możliwość nieodpłatnego dostępu do informacji o kursach walutowych stosowanych przez bank, w szczególności w postaci zestawienia informacji w zakresie: 

65 

a) stosowanych przez bank kursów kupna i sprzedaży waluty obcej, 

b) odrębnego zestawienia stosowanych przez bank spreadów walutowych. 

Minimalny zakres przedstawianych informacji powinien obejmować okres od 1 stycznia 2008 r. o ile bank nie ma możliwości dostarczenia dłuższej historii danych. 

- 25.11. Niezależnie od wymogów przewidzianych w ustawie, a w szczególności, gdy poniższy scenariusz jest bardziej dotkliwy dla klienta, rekomenduje się, aby bank przedstawiając klientowi ofertę kredytu zabezpieczonego hipotecznie lub innego produktu, oprocentowanego zmienną stopą procentową lub okresowo stałą stopą procentową informował klienta o kosztach obsługi ekspozycji kredytowej w wypadku niekorzystnej dla klienta zmiany oprocentowania kredytu. Informacje takie powinny być przekazane na przykład w postaci symulacji wysokości rat ekspozycji kredytowej. Informacje przekazywane klientowi powinny w szczególności zawierać porównanie kosztów obsługi ekspozycji kredytowej przy: 

a) aktualnym poziomie oprocentowania kredytu, 

b) wzroście oprocentowania kredytu o 400 p.b., 

c)[44)] wzroście oprocentowania kredytu w skali odpowiadającej różnicy między maksymalnym i minimalnym poziomem oprocentowania kredytu w okresie poprzedzającym datę sporządzenia informacji równym co najmniej planowanemu okresowi kredytowania (w przypadku braku danych historycznych należy uwzględnić dane dla najdłuższego dostępnego okresu), 

d) wskaźniku referencyjnym na poziomie 3%, 5% oraz 10%, powiększonym o marżę kredytu. 

Informacje wymienione w pkt b-d powinny być przekazywane klientowi ubiegającemu się o kredyt zabezpieczony hipotecznie oprocentowany zmienną stopą procentową i okresowo stałą stopą procentową, a założenia te powinny odnosić się do okresu, dla którego oprocentowanie jest zmienne. 

- 25.12. W celu uniknięcia wpływu w jednym czasie dużej liczby wniosków o zmianę formuły oprocentowania kredytu zabezpieczonego hipotecznie ze zmiennej stopy procentowej na stałą stopę procentową lub okresowo stałą stopę procentową, bank może z zachowaniem odstępów czasowych informować klientów o możliwości i sposobach dokonania zmiany formuły. Bank może określić w procedurach wewnętrznych zasady wyznaczania kolejności informowania klientów o możliwości dokonania zmiany formuły. 

## **Rekomendacja 26** 

**Bank powinien przedstawiać klientom detalicznym pełną posiadaną ofertę w zakresie kredytów zabezpieczonych hipotecznie na nieruchomościach mieszkalnych, tj. zarówno kredytów zabezpieczonych hipotecznie oprocentowanych zmienną stopą procentową, jak i** 

44) W brzmieniu ustalonym przez § 1 pkt 8 lit. c uchwały, o której mowa w odnośniku 1. 

66 

## **kredytów zabezpieczonych hipotecznie oprocentowanych stałą stopą procentową lub kredytów zabezpieczonych hipotecznie oprocentowanych okresowo stałą stopą procentową.** 

- 26.1. Bank powinien w jasny i przejrzysty sposób informować o ofercie kredytów zabezpieczonych hipotecznie oprocentowanych stałą stopą procentową i okresowo stałą stopą procentową, z uwzględnieniem specyfiki oferowanych przez siebie produktów, przekazując wyczerpującą informację dotyczącą charakterystyki czynników ryzyka związanych z każdym rodzajem oferowanego produktu, poprzez wykorzystanie zróżnicowanych środków przekazu (reklamy komercyjne, materiały reklamowe, broszury informacyjne). Informacje powinny być tak sformułowane, aby przedstawiały wady i zalety poszczególnych produktów w sposób prosty i rzetelny oraz aby nie wprowadzały w błąd. 

- 26.2. W przypadku kredytów zabezpieczonych hipotecznie oprocentowanych okresowo stałą stopą procentową, bank powinien dołożyć wszelkich starań, aby skutecznie poinformować i przekazać klientowi niezbędne wyjaśnienia do zgłaszanych wątpliwości o ograniczonym okresie obowiązywania stałej stopy procentowej z uwzględnieniem specyfiki konkretnego produktu. 

- 26.3. Bank powinien w czytelny i wyczerpujący sposób informować klientów o kosztach związanych z wcześniejszą spłatą kredytu, w szczególności w przypadku kredytów zabezpieczonych hipotecznie oprocentowanych stałą stopą procentową lub okresowo stałą stopą procentową. Informacje te powinny zostać zawarte w umowie kredytowej. 

## **Rekomendacja 27** 

## **W relacjach z klientami, w obszarze działalności związanej z ekspozycjami kredytowymi zabezpieczonymi hipotecznie bank powinien stosować zasady profesjonalizmu, rzetelności, staranności oraz najlepszej wiedzy.** 

- 27.1. Bank oferując produkty objęte postanowieniami niniejszej Rekomendacji powinien zapewnić: 

   - a) rzetelność rozpowszechnianych informacji reklamowych dotyczących oferowanych produktów, 

   - b) rzetelność i kompletność informacji przekazywanych klientom na temat oferowanych produktów, w tym w szczególności informacji o wszystkich czynnikach ryzyka związanych z danym produktem, 

   - c) jednoznaczność i zrozumiałość postanowień zawartych we wzorcach umowy, regulaminach, taryfach opłat i prowizji oraz treści zamieszczanych w innych dokumentach, a mających znaczenie dla podjęcia przez klienta decyzji o zaciągnięciu zobowiązania kredytowego, tak aby konsumenci mogli przewidzieć konsekwencje ekonomiczne, jakie wynikają dla nich z danych postanowień umownych, 

   - d) doręczenie klientom wszelkich dokumentów niezbędnych do podjęcia decyzji przed zawarciem umowy. 

67 

- 27.2. Niezależnie od wymogów przewidzianych w ustawie, umowa z każdym klientem, która dotyczy ekspozycji kredytowych zabezpieczonych hipotecznie oprocentowanych zmienną stopą procentową lub okresowo stałą stopą procentową powinna zawierać co najmniej postanowienia dotyczące: 

   - a) sposobów i warunków ustalania stopy procentowej, na podstawie której wyliczana jest wysokość rat kapitałowo-odsetkowych, 

   - b) informacji, że zmiana stopy procentowej będzie miała wpływ na wartość ekspozycji kredytowej oraz wysokość rat kapitałowo-odsetkowych, 

   - c) warunków i konsekwencji zmiany sposobu oprocentowania. 

- 27.3. Niezależnie od wymogów przewidzianych w ustawie, umowa z każdym klientem, która dotyczy ekspozycji kredytowych zabezpieczonych hipotecznie oprocentowanych okresowo stałą stopą procentową powinna zawierać co najmniej: 

   - a) informacje o ograniczonym okresie obowiązywania stałej stopy, 

   - b) postanowienia dotyczące sposobu i warunków ustalania stopy procentowej po okresie obowiązywania stałej stopy procentowej, z uwzględnieniem art. 29 ust. 3 ustawy o kredycie hipotecznym oraz o nadzorze nad pośrednikami kredytu hipotecznego i agentami. 

- 27.4. Rekomenduje się, aby w przypadku klientów ubiegających się o detaliczną ekspozycję kredytową, dla których wskaźnik DStI przekracza 40% lub 50% (zgodnie z postanowieniem Rekomendacji 25.6), bank poinformował o podwyższonym ryzyku tego produktu oraz niekorzystnym wpływie na sytuację ekonomiczną klienta, w tym na możliwość realizacji większych wydatków. Bank przekazuje klientowi stosowne oświadczenie na piśmie _._ 

68 

## **Spis treści** 

|Wstęp ........................................................................................................................................................... 2|Wstęp ........................................................................................................................................................... 2|
|---|---|
|Słowniczek stosowanych pojęć ................................................................................................................. 11||
|Spis|rekomendacji ..................................................................................................................................... 17|
|I.|Zarząd i rada nadzorcza ..................................................................................................................... 22|
|II.|Identyfikacja, pomiar i ocena ryzyka ekspozycji kredytowych zabezpieczonych hipotecznie ......... 33|
|III.|Zabezpieczenia .................................................................................................................................. 43|
|IV.|Monitorowanie i raportowanie w zakresie ryzyka ekspozycji kredytowych zabezpieczonych|
|hipotecznie ................................................................................................................................................. 51||
|V.|System kontroli wewnętrznej............................................................................................................. 61|
|VI.|Relacje z klientami ............................................................................................................................ 63|



69 

